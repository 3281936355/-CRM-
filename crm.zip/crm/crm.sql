/*
 Navicat MySQL Data Transfer

 Source Server         : db01
 Source Server Type    : MySQL
 Source Server Version : 50737
 Source Host           : localhost:3306
 Source Schema         : crm

 Target Server Type    : MySQL
 Target Server Version : 50737
 File Encoding         : 65001

 Date: 25/07/2022 20:32:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for agreement
-- ----------------------------
DROP TABLE IF EXISTS `agreement`;
CREATE TABLE `agreement`  (
  `aid` int(11) NOT NULL AUTO_INCREMENT COMMENT '合同表主键',
  `aname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '合同名称',
  `cname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构名称',
  `ctype` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '合同类型',
  `quality` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '合同性质',
  `operator` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '合同经办人',
  `total` decimal(11, 0) NULL DEFAULT NULL COMMENT '合同总金额',
  `payType` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '付款方式',
  `payDate` date NULL DEFAULT NULL COMMENT '签约日期',
  `startDate` date NULL DEFAULT NULL COMMENT '合同开始日期',
  `endDate` date NULL DEFAULT NULL COMMENT '合同结束日期',
  `signer` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '签字人',
  `state` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '审核状态',
  PRIMARY KEY (`aid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of agreement
-- ----------------------------
INSERT INTO `agreement` VALUES (1, '合同1', '中国联通', '国企', '5', '小明', 500000000, '银行卡', '2022-07-12', '2021-01-01', '2022-07-12', '小明', '通过');
INSERT INTO `agreement` VALUES (2, '合同2', '中国移动', '国企', '5', '小白', 666666666, '银行卡', '2022-07-12', '2021-07-12', '2024-07-12', '小白', '通过');
INSERT INTO `agreement` VALUES (3, '合同3333', '中国移动3', '国企3', '35', '小张3', 2000000003, '银行卡3', '2020-07-13', '2020-02-14', '2022-08-03', '小张3', '通过');

-- ----------------------------
-- Table structure for business
-- ----------------------------
DROP TABLE IF EXISTS `business`;
CREATE TABLE `business`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '活动id',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '活动内容',
  `price` decimal(10, 0) NULL DEFAULT NULL COMMENT '活动经费',
  `userid` int(11) NULL DEFAULT NULL COMMENT '活动负责人',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `business_users_fk`(`userid`) USING BTREE,
  CONSTRAINT `business_users_fk` FOREIGN KEY (`userid`) REFERENCES `users` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of business
-- ----------------------------
INSERT INTO `business` VALUES (1, '尚街九号开业活动细则一、连环购物抽奖活动：1.连环购物抽奖活动只在所有全款商户中进行。2.消费者消费后可获得两联小票。凭票即可参加商场开业连环购物抽奖活动及整点抽奖活动', 1200, 2);
INSERT INTO `business` VALUES (2, '为用户和管理员提供登录端口，若登录信息与数据库不符则提示“错误的用户名及密码”，需重新输入。', 1500, 2);
INSERT INTO `business` VALUES (3, '用户键盘输入用户名、密码及验证码。检验用户身份，存在相应的身份证号码则进入客户端界面，否则返回失败信息', 1000, 2);
INSERT INTO `business` VALUES (4, '输入添加信息后：保存信息、到达指定时间就会自动提醒；也可以对及进行删除、修改、查询以前日程。\r\n', 1200, 3);
INSERT INTO `business` VALUES (5, '输入添加信息后：保存信息、到达指定时间就会自动提醒；也可以对及进行删除、修改、查询以前日程。', 800, 3);

-- ----------------------------
-- Table structure for contact
-- ----------------------------
DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact`  (
  `contactid` int(10) NOT NULL AUTO_INCREMENT COMMENT '联系人id',
  `conname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人姓名',
  `condate` date NULL DEFAULT NULL COMMENT '出生日期',
  `nick` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `boss` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '老板',
  `wife` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '妻子',
  PRIMARY KEY (`contactid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 226 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contact
-- ----------------------------
INSERT INTO `contact` VALUES (221, '小明', '2022-07-09', '明明', '小明老板', '小花');
INSERT INTO `contact` VALUES (222, '小白', '2022-07-20', '白白', '小白老板', '小红');
INSERT INTO `contact` VALUES (223, '俞敏洪', '2022-07-05', '小鱼', NULL, '杨桂青');
INSERT INTO `contact` VALUES (224, '马云', '1971-01-09', 'jack马', NULL, '张瑛');
INSERT INTO `contact` VALUES (225, '刘强东', '1979-01-01', '东子', NULL, '奶茶妹妹');

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT '客户机构表主键',
  `cname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构名称',
  `address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构地址',
  `contact` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机',
  `mail` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '电子邮件',
  `latent` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '1:客户2:潜在客户',
  `source` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '客户来源',
  `englishname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '英文名',
  `job` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '职务',
  `dept` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门',
  `deptmanager` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门负责人',
  `fax` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '传真',
  `website` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '网站',
  `telephone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '办公电话',
  `statue` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '跟进状态',
  `statuedesc` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态说明',
  `contactid` int(10) NULL DEFAULT NULL COMMENT '联系人id',
  PRIMARY KEY (`cid`) USING BTREE,
  INDEX `customer_contact_fk`(`contactid`) USING BTREE,
  CONSTRAINT `customer_contact_fk` FOREIGN KEY (`contactid`) REFERENCES `contact` (`contactid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (2, '中国石油', '湖北武汉', '小明', '123123123', 'aaaaa@qq.com', '1', '网络', 'xiaom', '经理', '营销部', '张三', NULL, NULL, '2222', '已签约', NULL, 221);
INSERT INTO `customer` VALUES (3, '中国电信', '湖北武汉', '小白', '123213123', 'asdfa@163.com', '1', '网络', 'xiaobai', '经理', '营销部', '张三', NULL, NULL, '2222', '已签约', NULL, 222);
INSERT INTO `customer` VALUES (4, '新东方', '北京', '俞敏洪', '12312312', 'yu@qq.com', '1', '网络', 'yuminghong', 'CEO', '营销部', '张三', NULL, NULL, '2222', '在跟进', NULL, 223);
INSERT INTO `customer` VALUES (5, '阿里巴巴', '浙江杭州', '马云', '123412', 'ma@qq.com', '2', '网络', 'jack ma', 'CEO', '总裁办公室', '张三', NULL, 'www.alibab.com', '2222', '洽谈', NULL, 224);
INSERT INTO `customer` VALUES (6, '京东', '北京', '刘强东', '12312312', 'qiangdong@qq.com', '2', NULL, 'liu', 'CEO', '总裁办公室', '张三', NULL, 'www.jd.com', '2222', '洽谈', NULL, 225);

-- ----------------------------
-- Table structure for dept
-- ----------------------------
DROP TABLE IF EXISTS `dept`;
CREATE TABLE `dept`  (
  `depid` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门表id',
  `depname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门名称',
  `depdesc` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门简介',
  PRIMARY KEY (`depid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 889 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dept
-- ----------------------------
INSERT INTO `dept` VALUES (1, '研发部', '研发新产品');
INSERT INTO `dept` VALUES (2, '市场部', '销售新产品2');
INSERT INTO `dept` VALUES (3, '财务部', '管理公司账务');
INSERT INTO `dept` VALUES (4, '人力资源部', '管理公司人员的流动转岗2333');
INSERT INTO `dept` VALUES (8, '部门8', '部门888');

-- ----------------------------
-- Table structure for emp
-- ----------------------------
DROP TABLE IF EXISTS `emp`;
CREATE TABLE `emp`  (
  `eid` int(11) NOT NULL AUTO_INCREMENT COMMENT '员工表主键',
  `ename` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工姓名',
  `eno` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工工号',
  `job` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '岗位名称',
  `duty` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '岗位职责',
  `sex` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮件',
  `qq` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'QQ',
  `elevel` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '职位级别',
  `state` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工状态',
  `isLeave` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '是否离职',
  `isAssign` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分配状态',
  `remarks` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `dept` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门',
  PRIMARY KEY (`eid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of emp
-- ----------------------------
INSERT INTO `emp` VALUES (2, '李四', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL);
INSERT INTO `emp` VALUES (3, '王五', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback`  (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构名称',
  `cancat` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `fdate` date NULL DEFAULT NULL COMMENT '反馈时间',
  `mobile` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机',
  `purpose` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '反馈目的',
  `result` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '反馈结果',
  `state` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '反馈状态',
  `operator` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`fid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES (2, '中国移动', '李总', '2022-07-14', '12312312', '下次继续合作', '正在跟进', '已收到反馈', 'lisi');
INSERT INTO `feedback` VALUES (3, '中国电信22222222', '王经理', '2022-07-14', '12312321', '有点问题', '正在跟进', '已收到反馈', 'lisi');
INSERT INTO `feedback` VALUES (4, '中国石油', '张经理', '2022-07-14', '123123123', '什么时候到账', '已处理', '已收到反馈', 'wangwu');
INSERT INTO `feedback` VALUES (5, '中国石化', '赵经理', '2022-07-14', '1231313123', '什么时候到账', '已处理', '已收到反馈', 'wangwu');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '产品表主键',
  `pname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '产品名称',
  `ptype` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '产品类别',
  `info` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '产品介绍',
  `server` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '产品服务',
  `price` decimal(11, 0) NULL DEFAULT NULL COMMENT '产品报价',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (3, '怡宝', '矿泉水', '好', '送货上门', 1400);
INSERT INTO `product` VALUES (4, '恒大冰泉', '矿泉水', '好', '送货上门', 2600);
INSERT INTO `product` VALUES (5, '可口可乐', '饮料', '好喝', '送货上门', 2600);
INSERT INTO `product` VALUES (6, '百事可恶', '饮料', '好喝', '送货上门', 2500);

-- ----------------------------
-- Table structure for project
-- ----------------------------
DROP TABLE IF EXISTS `project`;
CREATE TABLE `project`  (
  `pid` int(10) NOT NULL AUTO_INCREMENT COMMENT '项目id',
  `proname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '项目名称',
  `describes` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '项目描述',
  `starttime` date NULL DEFAULT NULL COMMENT '项目开始时间',
  `endtime` date NULL DEFAULT NULL COMMENT '项目结束时间',
  `uid` int(10) NULL DEFAULT NULL COMMENT '用户id外键',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of project
-- ----------------------------
INSERT INTO `project` VALUES (1, '项目1', '做10000个充电桩', '2022-07-08', '2022-08-01', 2);
INSERT INTO `project` VALUES (2, '项目2', '新建3条地铁线路', '2022-07-08', '2022-10-01', 2);
INSERT INTO `project` VALUES (3, '项目3', '做电子基站', '2022-07-08', '2023-03-01', 3);
INSERT INTO `project` VALUES (4, '项目4', '安装宽带', '2022-07-14', '2022-10-01', 3);
INSERT INTO `project` VALUES (5, '5', '5', '2022-02-02', '2022-02-03', 3);
INSERT INTO `project` VALUES (6, '6', '6', '2022-06-06', '2023-06-07', 3);
INSERT INTO `project` VALUES (7, '333', '333', '2022-03-03', '2022-03-04', 2);
INSERT INTO `project` VALUES (8, '4', '4', '2022-02-02', '2022-03-03', 2);
INSERT INTO `project` VALUES (9, '555', '555', '2022-02-03', '2022-03-03', 2);
INSERT INTO `project` VALUES (11, '7', '7', '2022-02-02', '2022-02-02', 3);
INSERT INTO `project` VALUES (16, '9', '99', '2022-02-09', '2022-02-09', 3);

-- ----------------------------
-- Table structure for schedule
-- ----------------------------
DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule`  (
  `sid` int(10) NOT NULL AUTO_INCREMENT COMMENT '日程id',
  `sdate` date NULL DEFAULT NULL COMMENT '日期',
  `task` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '任务',
  `taskphone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '需要处理的电话',
  `meeting` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '会议',
  `uid` int(10) NULL DEFAULT NULL COMMENT '用户外键',
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of schedule
-- ----------------------------
INSERT INTO `schedule` VALUES (1, '2022-07-08', '与客户xx1进行回访', '123123131', '9：30分到会议室开会', 2);
INSERT INTO `schedule` VALUES (2, '2022-07-09', '与客户xx2进行回访', '232423424', '14：30到1楼会议室开会', 2);
INSERT INTO `schedule` VALUES (3, '2022-07-10', '与客户xx3进行回访', '123123123', '18：00下班前开会', 3);
INSERT INTO `schedule` VALUES (4, '2022-07-14', 'xxxx', '123131231', '开会', 3);
INSERT INTO `schedule` VALUES (5, '2022-01-01', '33', '3333', '333', 2);
INSERT INTO `schedule` VALUES (10, '2022-07-15', '777', '777', '777', 3);
INSERT INTO `schedule` VALUES (15, '2022-02-02', '88', '88', '88', 3);
INSERT INTO `schedule` VALUES (17, '2022-02-03', '23', '23', '23', 23);
INSERT INTO `schedule` VALUES (18, '2022-02-03', '223', '223', '223', 223);
INSERT INTO `schedule` VALUES (19, '2022-02-03', '23', '23', '23', 23);
INSERT INTO `schedule` VALUES (22, '2022-07-09', 'qq', '131231', '开会', 2);
INSERT INTO `schedule` VALUES (23, '2022-07-25', '开会', '123123', '开会', 2);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户表主键',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `upwd` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `power` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限',
  `depid` int(11) NULL DEFAULT NULL COMMENT '外键',
  PRIMARY KEY (`uid`) USING BTREE,
  INDEX `users_dept_fk`(`depid`) USING BTREE,
  CONSTRAINT `users_dept_fk` FOREIGN KEY (`depid`) REFERENCES `dept` (`depid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'zhangsan2', '123123', '管理员', 4);
INSERT INTO `users` VALUES (2, 'lisi', '123', '员工', 2);
INSERT INTO `users` VALUES (3, 'wangwu', '123', '员工', 1);
INSERT INTO `users` VALUES (4, '小明', '123', '员工', 3);
INSERT INTO `users` VALUES (7, 'aa', 'aa', '管理员', 4);
INSERT INTO `users` VALUES (8, 'aa', 'aa', '管理员', 2);
INSERT INTO `users` VALUES (9, 'bb', 'bb', '员工', 3);
INSERT INTO `users` VALUES (10, 'cc', 'cc', '管理员', 3);
INSERT INTO `users` VALUES (12, 'qqqq', 'qq', '员工', 3);
INSERT INTO `users` VALUES (14, 'qq', 'qq', '员工', 2);
INSERT INTO `users` VALUES (15, 'qwe', 'qwe', '员工', 4);
INSERT INTO `users` VALUES (16, 'rr', 'rr', '员工', 8);

SET FOREIGN_KEY_CHECKS = 1;
