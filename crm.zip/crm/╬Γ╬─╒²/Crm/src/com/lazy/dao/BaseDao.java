package com.lazy.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
  
public class BaseDao {  
    private static Connection conn;  
    private static PreparedStatement ps;  
    private static ResultSet rs;  
  
    public boolean execute(String sql, Object... objects) {  
        try {  
            conn = DBConnection.getConn();  
            ps = conn.prepareStatement(sql);  
            if (objects != null) {  
                for (int i = 0; i < objects.length; i++) {  
                    ps.setObject(i + 1, objects[i]);  
                }  
                int result = ps.executeUpdate();  
                return result > 0;  
            }
        }catch (SQLException e) {  
                e.printStackTrace();  
            } finally {  
                DBConnection.close(rs, ps, conn);  
            }  
            return false;  
        }  
  
      
        public  ResultSet query(String sql, Object... objects) {  
            try {  
                conn = DBConnection.getConn();  
                ps = conn.prepareStatement(sql);  
                if (objects != null) {  
                    for (int i = 0; i < objects.length; i++) {  
                        ps.setObject(i + 1, objects[i]);  
                    }  
                    rs = ps.executeQuery();  
                }
            }catch (SQLException e) {  
                    e.printStackTrace();  
                }  
                return rs;  
            }
        }
  
      

