package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WAdd extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WAdd frame = new WAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WAdd() {
		setTitle("\u6DFB\u52A0\u9879\u76EE\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 501);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u9879\u76EE\u540D\u79F0\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblNewLabel.setBounds(78, 59, 106, 33);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(181, 59, 206, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u9879\u76EE\u63CF\u8FF0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label.setBounds(78, 121, 106, 33);
		contentPane.add(label);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(181, 121, 206, 31);
		contentPane.add(textField_1);
		
		JLabel label_1 = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_1.setBounds(78, 188, 106, 33);
		contentPane.add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(181, 188, 206, 31);
		contentPane.add(textField_2);
		
		JLabel label_2 = new JLabel("\u7ED3\u675F\u65F6\u95F4\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_2.setBounds(78, 251, 106, 33);
		contentPane.add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(181, 251, 206, 31);
		contentPane.add(textField_3);
		
		JLabel label_3 = new JLabel("\u7528      \u6237\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_3.setBounds(78, 324, 106, 33);
		contentPane.add(label_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(181, 324, 206, 31);
		contentPane.add(textField_4);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ����
				String proname = textField.getText();
				String describes = textField_1.getText();
				String starttime = textField_2.getText();
				String endtime = textField_3.getText();
				String uid = textField_4.getText();
				String sql = "insert into project (proname,describes,starttime,endtime,uid) values(?,?,?,?,?)";
			
				BaseDao baseDao = new BaseDao();
				if (baseDao.execute(sql, proname,describes,starttime,endtime,uid)) {
					dispose();
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
				} else {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
				}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 18));
		btnNewButton.setBounds(78, 380, 113, 39);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.setFont(new Font("΢���ź�", Font.BOLD, 18));
		button.setBounds(274, 380, 113, 39);
		contentPane.add(button);
	}
}
