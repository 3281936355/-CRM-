package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UAdd extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UAdd frame = new UAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UAdd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 544, 508);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u65E5\u671F\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		lblNewLabel.setBounds(131, 116, 54, 33);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("\u4EFB\u52A1\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label.setBounds(131, 172, 54, 33);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u7535\u8BDD\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(131, 218, 54, 33);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u4F1A\u8BAE\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_2.setBounds(131, 264, 54, 33);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u7ECF\u529E\u4EBA\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_3.setBounds(131, 310, 72, 33);
		contentPane.add(label_3);
		
		textField = new JTextField();
		textField.setBounds(208, 122, 173, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 178, 173, 27);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(208, 224, 173, 27);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 270, 173, 27);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(208, 316, 173, 27);
		contentPane.add(textField_4);
		
		JLabel lblNewLabel_1 = new JLabel("\u6DFB\u52A0\u4FE1\u606F");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(221, 40, 107, 33);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {


				// ����
				// 1.��ȡ������ı�
				String sdate = textField.getText();
				String task = textField_1.getText();
				String taskphone = textField_2.getText();
				String meeting = textField_3.getText();
				String uid = textField_4.getText();
		
				// ����
				String sql = "insert into schedule(sdate,task,taskphone,meeting,uid) values(?,?,?,?,?)";
				BaseDao baseDao = new BaseDao();
				if(baseDao.execute(sql, sdate,task,taskphone,meeting,uid)) {
					// ˢ������
				dispose();
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
				}else {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
				}
			
			
			}
		});
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(77, 377, 113, 33);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Umain umain = new Umain();
					umain.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(268, 377, 113, 33);
		contentPane.add(button);
	}
}
