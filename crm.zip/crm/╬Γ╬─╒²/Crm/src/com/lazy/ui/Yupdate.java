package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Yupdate extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Yupdate frame = new Yupdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Yupdate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 455, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("\u8D26\u53F7\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label.setBounds(100, 76, 54, 33);
		contentPane.add(label);

		JLabel label_1 = new JLabel("\u5BC6\u7801\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(100, 132, 54, 33);
		contentPane.add(label_1);

		JLabel label_2 = new JLabel("\u6743\u9650\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_2.setBounds(100, 178, 54, 33);
		contentPane.add(label_2);

		JLabel label_3 = new JLabel("\u90E8\u95E8\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_3.setBounds(100, 224, 54, 33);
		contentPane.add(label_3);

		textField_1 = new JTextField();
		textField_1.setText((String) null);
		textField_1.setColumns(10);
		textField_1.setBounds(177, 230, 173, 27);
		contentPane.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setText((String) null);
		textField_2.setColumns(10);
		textField_2.setBounds(177, 184, 173, 27);
		contentPane.add(textField_2);

		textField_3 = new JTextField();
		textField_3.setText((String) null);
		textField_3.setColumns(10);
		textField_3.setBounds(177, 138, 173, 27);
		contentPane.add(textField_3);

		textField_4 = new JTextField();
		textField_4.setText((String) null);
		textField_4.setColumns(10);
		textField_4.setBounds(177, 82, 173, 27);
		contentPane.add(textField_4);

		textField_4.setText(Main.users.getUsername());
		textField_3.setText(Main.users.getUpwd());
		textField_2.setText(Main.users.getPower());
		textField_1.setText(Main.users.getDept().getDepname());

		JButton button = new JButton("\u786E\u8BA4\u4FEE\u6539");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = textField_4.getText();
				String upwd = textField_3.getText();
				String power = textField_2.getText();
				String depid = textField_1.getText();

				String sql = "update users set username=?,upwd=?,power=?, depid=? where uid=?";
				BaseDao baseDao = new BaseDao();
				if (baseDao.execute(sql, username, upwd, power, depid, Main.users.getUid())) {
					JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(68, 302, 113, 33);
		contentPane.add(button);

		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(237, 302, 113, 33);
		contentPane.add(button_1);

		JLabel label_5 = new JLabel("\u4FEE\u6539\u4FE1\u606F");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_5.setBounds(190, 0, 107, 33);
		contentPane.add(label_5);
	}
}
