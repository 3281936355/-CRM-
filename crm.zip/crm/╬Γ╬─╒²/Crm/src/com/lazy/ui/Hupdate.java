package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Hupdate extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Hupdate frame = new Hupdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Hupdate() {
		setTitle("\u4FEE\u6539\u5408\u540C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 497, 633);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(10, -13, 455, 622);
		contentPane.add(panel);
		
		JLabel label = new JLabel("\u5408\u540C\u540D\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label.setBounds(77, 114, 91, 26);
		panel.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(178, 114, 191, 27);
		panel.add(textField);
		
		JLabel label_1 = new JLabel("\u673A\u6784\u540D\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_1.setBounds(77, 150, 91, 26);
		panel.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(178, 150, 191, 27);
		panel.add(textField_1);
		
		JLabel label_2 = new JLabel("\u4F01\u4E1A\u7C7B\u578B\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_2.setBounds(77, 186, 91, 26);
		panel.add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(178, 186, 191, 27);
		panel.add(textField_2);
		
		JLabel label_3 = new JLabel("\u4F01\u4E1A\u7B49\u7EA7\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_3.setBounds(77, 220, 91, 26);
		panel.add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(178, 220, 191, 27);
		panel.add(textField_3);
		
		JLabel label_4 = new JLabel("\u64CD\u4F5C\u4EBA\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_4.setBounds(77, 256, 91, 26);
		panel.add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(178, 256, 191, 27);
		panel.add(textField_4);
		
		JLabel label_5 = new JLabel("\u603B\u91D1\u989D\uFF1A");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_5.setBounds(77, 292, 91, 26);
		panel.add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(178, 295, 191, 27);
		panel.add(textField_5);
		
		JLabel label_6 = new JLabel("\u652F\u4ED8\u65B9\u5F0F\uFF1A");
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_6.setBounds(77, 331, 91, 26);
		panel.add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(178, 331, 191, 27);
		panel.add(textField_6);
		
		JLabel label_7 = new JLabel("\u652F\u4ED8\u65E5\u671F\uFF1A");
		label_7.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_7.setBounds(77, 367, 91, 26);
		panel.add(label_7);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(178, 367, 191, 27);
		panel.add(textField_7);
		
		JLabel label_8 = new JLabel("\u5408\u540C\u5F00\u59CB\uFF1A");
		label_8.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_8.setBounds(77, 403, 91, 26);
		panel.add(label_8);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(178, 403, 191, 27);
		panel.add(textField_8);
		
		JLabel label_9 = new JLabel("\u5408\u540C\u7ED3\u675F\uFF1A");
		label_9.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_9.setBounds(77, 439, 91, 26);
		panel.add(label_9);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(178, 439, 191, 27);
		panel.add(textField_9);
		
		JLabel label_10 = new JLabel("\u7B7E\u5B57\u4EBA\uFF1A");
		label_10.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_10.setBounds(77, 475, 91, 26);
		panel.add(label_10);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(178, 475, 191, 27);
		panel.add(textField_10);
		
		JLabel label_11 = new JLabel("\u72B6\u6001\uFF1A");
		label_11.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_11.setBounds(77, 511, 91, 26);
		panel.add(label_11);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(178, 511, 191, 27);
		panel.add(textField_11);
		
		textField.setText(Main.agreement.getAname());
		textField_1.setText(Main.agreement.getCanme());
		textField_2.setText(Main.agreement.getCtype());
		textField_3.setText(Main.agreement.getQuality());
		textField_4.setText(Main.agreement.getOperator());
		textField_5.setText(Main.agreement.getTotal());
		textField_6.setText(Main.agreement.getPayType());
		textField_7.setText(Main.agreement.getPayDate());
		textField_8.setText(Main.agreement.getStartDate());
		textField_9.setText(Main.agreement.getEndDate());
		textField_10.setText(Main.agreement.getSigner());
		textField_11.setText(Main.agreement.getState());

		
		JLabel label_12 = new JLabel("\u4FEE\u6539\u5408\u540C\u4FE1\u606F");
		label_12.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		label_12.setBounds(125, 35, 205, 33);
		panel.add(label_12);
		
		JButton button = new JButton("\u786E\u8BA4\u4FEE\u6539");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// �޸�
				String aname = textField.getText();
				String cname  = textField_1.getText();
				String ctype = textField_2.getText();
				String quality = textField_3.getText();
				String operator = textField_4.getText();
				String total = textField_5.getText();
				String payType = textField_6.getText();
				String payDate  = textField_7.getText();
				String startDate = textField_8.getText();
				String endDate = textField_9.getText();
				String signer = textField_10.getText();
				String state = textField_11.getText();
				String sql = "update agreement set aname=?,cname=?,ctype=?,quality=?,operator=?,total=?,payType=?,payDate=?,startDate=?,endDate=?,signer=?,state=? where aid =?";
				BaseDao baseDao = new BaseDao();
				if (baseDao.execute(sql, aname, cname, ctype, quality, operator, total, payType, payDate, startDate, endDate, signer, state,Main.agreement.getAid())) {
					JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�");
					
				}
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		button.setBounds(77, 560, 119, 38);
		panel.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//ȡ��
				dispose();
			}
		});
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		button_1.setBounds(250, 560, 119, 38);
		panel.add(button_1);
	}
}
