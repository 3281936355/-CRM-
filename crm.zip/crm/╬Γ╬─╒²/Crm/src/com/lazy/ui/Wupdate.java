package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Wupdate extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Wupdate frame = new Wupdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Wupdate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 465, 507);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u9879\u76EE\u540D\u79F0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label.setBounds(64, 41, 106, 33);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u9879\u76EE\u63CF\u8FF0\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_1.setBounds(64, 103, 106, 33);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_2.setBounds(64, 170, 106, 33);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u7ED3\u675F\u65F6\u95F4\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_3.setBounds(64, 233, 106, 33);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u7528      \u6237\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_4.setBounds(64, 306, 106, 33);
		contentPane.add(label_4);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(167, 306, 206, 31);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(167, 233, 206, 31);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(167, 170, 206, 31);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(167, 103, 206, 31);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(167, 41, 206, 31);
		contentPane.add(textField_4);
		//���
		textField_4.setText(Umain.project.getProname());
		textField_3.setText(Umain.project.getDescribes());
		textField_2.setText(Umain.project.getStarttime());
		textField_1.setText(Umain.project.getEndtime());
		textField.setText(Umain.project.getUid());



		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ȷ���޸�
				String proname = textField_4.getText();
				String describes = textField_3.getText();
				String starttime = textField_2.getText();
				String endtime = textField_1.getText();
				String uid = textField.getText();
				String sql =  "update project set proname = ?,describes =?,starttime = ?,endtime=?,uid=? where pid=?";
			BaseDao baseDao = new BaseDao();
			if (baseDao.execute(sql, proname,describes,starttime,endtime,uid,Umain.project.getPid())) {
				JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
				dispose();
			} else {
				JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�");
			}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 20));
		btnNewButton.setBounds(64, 382, 113, 33);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button.setFont(new Font("΢���ź�", Font.BOLD, 20));
		button.setBounds(222, 382, 113, 33);
		contentPane.add(button);
	}
}
