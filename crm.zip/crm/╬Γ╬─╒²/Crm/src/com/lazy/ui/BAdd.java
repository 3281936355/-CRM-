package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BAdd extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BAdd frame = new BAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BAdd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 457, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u90E8\u95E8\u540D\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label.setBounds(110, 95, 90, 41);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u90E8\u95E8\u63CF\u8FF0\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(110, 162, 90, 41);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 101, 163, 33);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(208, 168, 163, 33);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_1 = new JLabel("\u6DFB\u52A0\u4FE1\u606F");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(189, 30, 104, 33);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String depname = textField_1.getText();
				String depdesc = textField_2.getText();
				String sql = "insert into dept(depname,depdesc) values(?,?)";
				BaseDao baseDao = new BaseDao();
			if (baseDao.execute(sql,depname, depdesc)) {
				
				dispose();
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			
			}else {
				JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");

			}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		btnNewButton.setBounds(83, 233, 122, 41);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main main = new Main();
				main.setVisible(true);
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button.setBounds(249, 233, 122, 41);
		contentPane.add(button);
	}
}
