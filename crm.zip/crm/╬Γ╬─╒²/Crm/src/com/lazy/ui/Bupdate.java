package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Bupdate extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bupdate frame = new Bupdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bupdate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 459, 341);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u4FEE\u6539\u4FE1\u606F");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label.setBounds(183, 25, 104, 33);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u90E8\u95E8\u540D\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(104, 90, 90, 41);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u90E8\u95E8\u63CF\u8FF0\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_2.setBounds(104, 157, 90, 41);
		contentPane.add(label_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(202, 96, 163, 33);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(202, 163, 163, 33);
		contentPane.add(textField_1);
		
		textField.setText(Main.dept.getDepname());
		textField_1.setText(Main.dept.getDepdesc());
		
		JButton button = new JButton("\u786E\u8BA4\u4FEE\u6539");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String depname = textField.getText();
				String depdesc = textField_1.getText();
				String sql = "update dept set depname=?,depdesc=? where depid=?";
				BaseDao baseDao = new BaseDao();
				if (baseDao.execute(sql, depname,depdesc,Main.dept.getDepid())) {
					
					
					JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					dispose();
					
					
				} else {
					JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�");
				}
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button.setBounds(77, 228, 122, 41);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main main = new Main();
				main.setVisible(true);
			}
		});
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button_1.setBounds(243, 228, 122, 41);
		contentPane.add(button_1);
	}

}
