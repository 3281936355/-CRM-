package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UUpdate extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UUpdate frame = new UUpdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UUpdate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 530, 510);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(0, 0, 526, 461);
		contentPane.add(panel);
		
		JLabel label = new JLabel("\u65E5\u671F\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label.setBounds(131, 116, 54, 33);
		panel.add(label);
		
		JLabel label_1 = new JLabel("\u4EFB\u52A1\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(131, 172, 54, 33);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("\u7535\u8BDD\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_2.setBounds(131, 218, 54, 33);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("\u4F1A\u8BAE\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_3.setBounds(131, 264, 54, 33);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("\u7ECF\u529E\u4EBA\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_4.setBounds(131, 310, 72, 33);
		panel.add(label_4);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(208, 122, 173, 27);
		panel.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 178, 173, 27);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(208, 224, 173, 27);
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 270, 173, 27);
		panel.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(208, 316, 173, 27);
		panel.add(textField_4);
		// ���
	textField.setText(Umain.schedule.getSdate());
	textField_1.setText(Umain.schedule.getTask());
	textField_2.setText(Umain.schedule.getTaskphone());
	textField_3.setText(Umain.schedule.getMeeting());
	textField_4.setText(Umain.schedule.getUid());

		
		JLabel label_5 = new JLabel("\u4FEE\u6539\u4FE1\u606F");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_5.setBounds(221, 40, 107, 33);
		panel.add(label_5);
		
		JButton button = new JButton("\u786E\u8BA4\u4FEE\u6539");
		button.addActionListener(new ActionListener() {
			//�޸�
			public void actionPerformed(ActionEvent e) {
				String sdate = textField.getText();
				String task = textField_1.getText();
				String taskphone = textField_2.getText();
				String meeting = textField_3.getText();
				String uid = textField_4.getText();
				String sql ="update schedule set sdate=?,task=?,taskphone=?, meeting=?,uid=? where sid=?";
				BaseDao baseDao = new BaseDao();	
	if (baseDao.execute(sql, sdate,task,taskphone,meeting,uid,Umain.schedule.getSid())) {
		
		
		JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
		dispose();
		
	} else {
		JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�");
	}
	
			
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(77, 377, 113, 33);
		panel.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Umain umain = null;
				try {
					umain = new Umain();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				umain.setVisible(true);
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(268, 377, 113, 33);
		panel.add(button_1);
	}
}
