package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.lazy.dao.BaseDao;
import com.lazy.pojo.Dept;
import com.lazy.pojo.Users;
import com.lazy.pojo.Users;
import com.lazy.pojo.Users;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;;

public class Yhgl extends JFrame {

	private JPanel contentPane;
	private static ArrayList<Users> userss;
	public static Users users;
	private JTextField textField;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Yhgl frame = new Yhgl();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void dataBind(String username) {
		// 1.��ȡ���ݿ�users
		BaseDao baseDao = new BaseDao();
		String sql = "select * from users join dept on users.depid = dept.depid where username like?";
		ResultSet rs = baseDao.query(sql,"%"+username+"%");
		// 2.ת����User����
		userss = new ArrayList<>();
		Users users = null;
		try {
			while(rs.next()) {
				users = new Users();
				users.setUid(rs.getInt("uid"));
				users.setUsername(rs.getString("username"));
				users.setUpwd(rs.getString("upwd"));
				users.setPower(rs.getString("power"));
				Dept dept = new Dept();
				dept.setDepid(rs.getInt("depid"));
				dept.setDepname(rs.getString("depname"));
				dept.setDepdesc(rs.getString("depdesc"));
				users.setDept(dept);
				userss.add(users);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Object[][] data = new Object[userss.size()][];
		for (int i = 0; i < userss.size(); i++) {
			data[i] = new Object[] {userss.get(i).getUid(),userss.get(i).getUsername(),userss.get(i).getUpwd(),userss.get(i).getPower(),userss.get(i).getDept().getDepname()};
		}
		table.setModel(new DefaultTableModel(
			data,
				new String[] {
					"\u7528\u6237\u7F16\u53F7", "\u7528\u6237\u540D", "\u5BC6\u7801", "\u6743\u9650", "\u90E8\u95E8"
				}
			));
	}
	/**
	 * Create the frame.
	 */
	public Yhgl() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 823, 476);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("\u7528\u6237\u7BA1\u7406");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �û�����
				Yhgl yhgl = new Yhgl();
				yhgl.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.BLACK);
		button.setBackground(Color.CYAN);
		button.setBounds(10, 172, 113, 36);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u4E2A\u4EBA\u4FE1\u606F\u7BA1\u7406");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Main main = new Main();
				main.setVisible(true);
			
			}
		});
		button_1.setForeground(Color.BLACK);
		button_1.setBackground(Color.CYAN);
		button_1.setBounds(10, 116, 129, 36);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("\u90E8\u95E8\u7BA1\u7406");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		button_2.setForeground(Color.BLACK);
		button_2.setBackground(Color.CYAN);
		button_2.setBounds(10, 226, 113, 36);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\u5408\u540C\u7BA1\u7406");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// ��ͬ����
				
				dispose();

			}
		});
		button_3.setForeground(Color.BLACK);
		button_3.setBackground(Color.CYAN);
		button_3.setBounds(10, 287, 113, 36);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("\u9000\u51FA");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.BLACK);
		button_4.setBackground(Color.CYAN);
		button_4.setBounds(10, 349, 113, 36);
		contentPane.add(button_4);
		
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u8F93\u5165\u67E5\u8BE2\u5185\u5BB9\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		lblNewLabel.setBounds(165, 120, 163, 29);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(309, 123, 240, 29);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton button_5 = new JButton("\u65B0\u589E");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				YAdd yAdd = new YAdd();
				yAdd.setVisible(true);
			}
		});
		button_5.setForeground(Color.BLACK);
		button_5.setBackground(Color.CYAN);
		button_5.setBounds(723, 172, 74, 36);
		contentPane.add(button_5);
		
		JButton button_6 = new JButton("\u5220\u9664");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				
				// ɾ��
				// �ж��Ƿ��б�ѡ�е���
				if (table.getSelectedRowCount()>0) {
					// �õ�������ʾ���ݵ��±�
					int index = table.getSelectedRow();
					// �õ���Ӧ���ݵ�Id�ֶ�
					int uid = userss.get(index).getUid();
					// ����sql���
					String sql = "delete from users where uid =?";
					//ִ��
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, uid)) {
						dataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}
			
			}
		});
		button_6.setForeground(Color.BLACK);
		button_6.setBackground(Color.CYAN);
		button_6.setBounds(723, 231, 74, 36);
		contentPane.add(button_6);
		
		JButton button_7 = new JButton("\u4FEE\u6539");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// �޸�
				// 1.
				
				if (table.getSelectedRowCount()>0) {
					int index = table.getSelectedRow();
					users = userss.get(index);
					Yupdate yupdate = new Yupdate();
					yupdate.setVisible(true);

				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");
				}
			
			}
		});
		button_7.setForeground(Color.BLACK);
		button_7.setBackground(Color.CYAN);
		button_7.setBounds(723, 280, 74, 36);
		contentPane.add(button_7);
		
		JButton button_8 = new JButton("\u5BFC\u51FA");
		button_8.setForeground(Color.BLACK);
		button_8.setBackground(Color.CYAN);
		button_8.setBounds(723, 330, 74, 36);
		contentPane.add(button_8);
		
		JButton button_9 = new JButton("\u67E5\u8BE2");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username =textField.getText();
				dataBind(username);
			}
		});
		button_9.setForeground(Color.BLACK);
		button_9.setBackground(Color.CYAN);
		button_9.setBounds(588, 116, 74, 36);
		contentPane.add(button_9);
		
		JLabel lblNewLabel_1 = new JLabel("CRM\u7BA1\u7406\u5458\u540E\u53F0\u754C\u9762");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(280, 28, 246, 37);
		contentPane.add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(133, 187, 564, 175);
		contentPane.add(scrollPane);
		
		table = new JTable();
		dataBind("");
		
		scrollPane.setViewportView(table);
		setLocationRelativeTo(null);
	}
}
