package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;
import com.lazy.pojo.Dept;
import com.lazy.pojo.Users;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Window;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JPasswordField txtPwd;
	public static String name;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			JFrame.setDefaultLookAndFeelDecorated(true);
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setBackground(Color.BLACK);
		setTitle("\u767B\u5F55");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 364);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblName = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblName.setBounds(108, 147, 113, 30);
		lblName.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		contentPane.add(lblName);

		JLabel lblPwd = new JLabel("\u5BC6\u7801\uFF1A");
		lblPwd.setBounds(126, 201, 90, 30);
		lblPwd.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		contentPane.add(lblPwd);

		txtName = new JTextField();
		txtName.setBounds(207, 150, 199, 36);
		contentPane.add(txtName);
		txtName.setColumns(10);

		JButton button = new JButton("\u767B\u5F55");
		button.setBounds(186, 247, 171, 41);
		button.addActionListener(new ActionListener() {

			private Window frame;

			public void actionPerformed(ActionEvent arg0) {
				// ��¼
				String username = txtName.getText();
				String upwd = txtPwd.getText();
				name = username;
				Users users = null;
				String sql = "select * from users where username=? and upwd=?";
				ResultSet rs = new BaseDao().query(sql, username, upwd);
				
				try {
					while (rs.next()) {
						users = new Users();
						users.setUid(rs.getInt("uid"));
						users.setUsername(rs.getString("username"));
						users.setUpwd(rs.getString("upwd"));
						users.setPower(rs.getString("power"));

						Dept dept = new Dept();
						dept.setDepid(rs.getInt("depid"));
						dept.setDepname(rs.getString("depname"));
						dept.setDepdesc(rs.getString("depdesc"));
						
						users.setDept(dept);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					if (username.equals("") || upwd.equals("")) {
						JOptionPane.showMessageDialog(null, "�˺Ż����벻ȫ��");
						return;
					}

					if (users != null) {
						if (users.getPower().equals("����Ա")) {
							Main main = new Main();
							main.setVisible(true);
							dispose();
							JOptionPane.showMessageDialog(null, "��ӭ" + username +"����Ա��¼!");
						} else {
							Umain umain = new Umain();
							umain.setVisible(true);
							dispose();
							JOptionPane.showMessageDialog(null, "��ӭ" + username + "Ա����¼!");
						}
					} else {
						JOptionPane.showMessageDialog(null, "�˺Ż��������");
					}
				} catch (HeadlessException e) {
				
					e.printStackTrace();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		});
		button.setBackground(Color.LIGHT_GRAY);
		contentPane.add(button);

		JLabel lblLogin = new JLabel("\u5BA2\u6237\u8D44\u6E90\u7BA1\u7406\u7CFB\u7EDFCRM");
		lblLogin.setBounds(121, 57, 312, 41);
		lblLogin.setForeground(Color.WHITE);
		lblLogin.setBackground(Color.WHITE);
		lblLogin.setFont(new Font("΢���ź�", Font.BOLD, 30));
		contentPane.add(lblLogin);

		txtPwd = new JPasswordField();
		txtPwd.setBounds(207, 206, 199, 31);
		contentPane.add(txtPwd);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-40, 0, 578, 326);
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/com/Crm/source/loginbg.jpeg")));
		contentPane.add(lblNewLabel);
		setLocationRelativeTo(null);
	}
}
