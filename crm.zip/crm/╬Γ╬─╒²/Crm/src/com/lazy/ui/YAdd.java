package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lazy.dao.BaseDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class YAdd extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					YAdd frame = new YAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public YAdd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label.setBounds(130, 112, 72, 33);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_1.setBounds(130, 168, 54, 33);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u7528\u6237\u6743\u9650\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_2.setBounds(119, 214, 90, 33);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u90E8\u95E8\u7F16\u53F7\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_3.setBounds(119, 260, 90, 33);
		contentPane.add(label_3);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(207, 266, 173, 27);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(207, 220, 173, 27);
		contentPane.add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(207, 118, 173, 27);
		contentPane.add(textField_4);
		
		JLabel label_5 = new JLabel("\u6DFB\u52A0\u4FE1\u606F");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_5.setBounds(220, 36, 107, 33);
		contentPane.add(label_5);
		
		JButton button = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = textField_4.getText();
				String upwd = textField.getText();
				String power = textField_2.getText();
				String depid = textField_1.getText();
				String sql = "insert into users (username,upwd,power,depid) values(?,?,?,?)";
			
				BaseDao baseDao =  new BaseDao();
				if (baseDao.execute(sql, username,upwd,power,depid)) {
					
					dispose();
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
				}else {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");

				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(76, 373, 113, 33);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Yhgl yhgl = new Yhgl();
				yhgl.setVisible(true);
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(267, 373, 113, 33);
		contentPane.add(button_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(207, 168, 173, 27);
		contentPane.add(textField);
	}
}
