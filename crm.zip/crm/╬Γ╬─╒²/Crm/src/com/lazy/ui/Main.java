                                                               package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.Date;




import com.lazy.dao.BaseDao;
import com.lazy.dao.ExcelExporter;
import com.lazy.pojo.Agreement;
import com.lazy.pojo.Dept;
import com.lazy.pojo.Users;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtName;
	private JTextField txtPwd;
	private JTextField txtPower;
	private JTextField txtDepid;
	private JTextField textYHGL;
	private JTable tableYHGL;
	private static ArrayList<Dept> depts;
	public static Dept dept;
	private static ArrayList<Agreement> agreements;
	public static Agreement agreement;
	private static ArrayList<Users> userss;
	public static Users users;
	private JTable tableBMGL;
	private JTextField textBMGL;
	private JTable tableHTGL;
	private JTextField textHTGL;
	private JLabel lblTimer;
	private Timer timer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			JFrame.setDefaultLookAndFeelDecorated(true);
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void updateTimer(){

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
		lblTimer.setText(sdf.format(date));
	
	}
	public void YHGLdataBind(String username) {
		// 1.��ȡ���ݿ�users
		BaseDao baseDao = new BaseDao();
		String sql = "select * from users join dept on users.depid = dept.depid where username like?";
		ResultSet rs = baseDao.query(sql,"%"+username+"%");
		// 2.ת����User����
		userss = new ArrayList<>();
		Users users = null;
		try {
			while(rs.next()) {
				users = new Users();
				users.setUid(rs.getInt("uid"));
				users.setUsername(rs.getString("username"));
				users.setUpwd(rs.getString("upwd"));
				users.setPower(rs.getString("power"));
				Dept dept = new Dept();
				dept.setDepid(rs.getInt("depid"));
				dept.setDepname(rs.getString("depname"));
				dept.setDepdesc(rs.getString("depdesc"));
				users.setDept(dept);
				userss.add(users);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Object[][] data = new Object[userss.size()][];
		for (int i = 0; i < userss.size(); i++) {
			data[i] = new Object[] {userss.get(i).getUid(),userss.get(i).getUsername(),userss.get(i).getUpwd(),userss.get(i).getPower(),userss.get(i).getDept().getDepname()};
		}
		tableYHGL.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u7528\u6237\u7F16\u53F7", "\u7528\u6237\u540D", "\u5BC6\u7801", "\u6743\u9650", "\u90E8\u95E8"
				}
			));
	}
	public void BMGLdataBind(String depname) {
		BaseDao baseDao = new BaseDao();
		String sql = "select* from dept where depname like?";
		ResultSet rs = baseDao.query(sql,"%"+depname+"%");
		depts  = new ArrayList<>();
		Dept dept = null;
		
		try {
			while (rs.next()) {
				dept = new Dept();
				dept.setDepid(rs.getInt("depid"));
				dept.setDepname(rs.getString("depname"));
				dept.setDepdesc(rs.getString("depdesc"));
				depts.add(dept);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[depts.size()][];
		for (int i = 0; i < depts.size(); i++) {
			data[i] = new Object[] {depts.get(i).getDepid(),depts.get(i).getDepname(),depts.get(i).getDepdesc()};
		}
		tableBMGL.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u90E8\u95E8\u7F16\u53F7", "\u90E8\u95E8\u540D", "\u90E8\u95E8\u63CF\u8FF0"
				}
			));
	}
	
	public void HTGLdataBind(String aname) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from agreement where aname like?";
		ResultSet rs = baseDao.query(sql,"%"+aname+"%");

		agreements = new ArrayList<>();
		Agreement agreement = null;

		try {
			while (rs.next()) {
				agreement = new Agreement();
				agreement.setAid(rs.getInt("aid"));
				agreement.setAname(rs.getString("aname"));
				agreement.setCanme(rs.getString("cname"));
				agreement.setCtype(rs.getString("ctype"));
				agreement.setQuality(rs.getString("quality"));
				agreement.setOperator(rs.getString("operator"));
				agreement.setTotal(rs.getString("total"));
				agreement.setPayType(rs.getString("payType"));
				agreement.setPayDate(rs.getString("payDate"));
				agreement.setStartDate(rs.getString("startDate"));
				agreement.setEndDate(rs.getString("endDate"));
				agreement.setSigner(rs.getString("signer"));
				agreement.setState(rs.getString("state"));
				agreements.add(agreement);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Object[][] data = new Object[agreements.size()][];
		for (int i = 0; i < agreements.size(); i++) {
			data[i] = new Object[]{
				
				agreements.get(i).getAid(),
				agreements.get(i).getAname(),
				agreements.get(i).getCanme(),
				agreements.get(i).getCtype(),
				agreements.get(i).getQuality(),
				agreements.get(i).getOperator(),
				agreements.get(i).getTotal(),
				agreements.get(i).getPayType(),
				agreements.get(i).getPayDate(),
				agreements.get(i).getStartDate(),
				agreements.get(i).getEndDate(),
				agreements.get(i).getSigner(),
				agreements.get(i).getState()					
			};
		}
		tableHTGL.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u5408\u540C\u7F16\u53F7", "\u5408\u540C\u540D", "\u673A\u6784\u540D", "\u4F01\u4E1A\u540D", "\u4F01\u4E1A\u7F16\u53F7", "\u64CD\u4F5C\u4EBA", "\u603B\u91D1\u989D", "\u652F\u4ED8\u65B9\u5F0F", "\u652F\u4ED8\u65F6\u95F4", "\u5408\u540C\u5F00\u59CB", "\u5408\u540C\u7ED3\u675F", "\u7B7E\u5B57\u4EBA", "\u72B6\u6001"
				}
			));
	}
	
	
	
	/**
	 * Create the frame.
	 */
	
	public Main() {
		setTitle("\u7BA1\u7406\u5458\u540E\u53F0\u754C\u9762");
		JPanel panelGRXX = new JPanel();
		JPanel panelYHGL = new JPanel();
		JPanel panelHTGL = new JPanel();
		JPanel panelBMGL = new JPanel();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 864, 529);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton button_1 = new JButton("\u4E2A\u4EBA\u4FE1\u606F\u7BA1\u7406");
		button_1.setBounds(32, 155, 129, 36);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// ������Ϣ����
				panelGRXX.show();
				panelYHGL.hide();
				panelBMGL.hide();
				panelHTGL.hide();
				
				
			}
		});
		contentPane.setLayout(null);
		button_1.setForeground(Color.BLACK);
		button_1.setBackground(Color.CYAN);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("\u7528\u6237\u7BA1\u7406");
		button_2.setBounds(32, 211, 113, 36);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//�û�����
				panelGRXX.hide();
				panelYHGL.show();
				panelBMGL.hide();
				panelHTGL.hide();
			
			}
		});
		button_2.setForeground(Color.BLACK);
		button_2.setBackground(Color.CYAN);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\u90E8\u95E8\u7BA1\u7406");
		button_3.setBounds(32, 265, 113, 36);
		button_3.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				panelGRXX.hide();
				panelYHGL.hide();
				panelBMGL.show();
				panelHTGL.hide();
				
			}
		});
		button_3.setForeground(Color.BLACK);
		button_3.setBackground(Color.CYAN);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("\u5408\u540C\u7BA1\u7406");
		button_4.setBounds(32, 326, 113, 36);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// ��ͬ����
				panelGRXX.hide();
				panelYHGL.hide();
				panelBMGL.hide();
				panelHTGL.show();
			}
		});
		button_4.setForeground(Color.BLACK);
		button_4.setBackground(Color.CYAN);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("\u9000\u51FA");
		button_5.setBounds(32, 388, 113, 36);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// �˳�
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		button_5.setForeground(Color.BLACK);
		button_5.setBackground(Color.CYAN);
		contentPane.add(button_5);
		panelGRXX.setBounds(167, 88, 679, 381);
		contentPane.add(panelGRXX);
		panelGRXX.setLayout(null);
		
		JLabel label_1 = new JLabel("ID:");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_1.setBounds(203, 96, 42, 18);
		panelGRXX.add(label_1);
		
		JLabel label_2 = new JLabel("\u7528\u6237\u540D:");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_2.setBounds(203, 127, 96, 28);
		panelGRXX.add(label_2);
		
		txtid = new JTextField();
		txtid.setColumns(10);
		txtid.setBounds(287, 96, 182, 26);
		panelGRXX.add(txtid);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(287, 134, 182, 26);
		panelGRXX.add(txtName);
		
		JLabel label_3 = new JLabel("\u5BC6\u7801:");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_3.setBounds(203, 168, 63, 29);
		panelGRXX.add(label_3);
		
		txtPwd = new JTextField();
		txtPwd.setColumns(10);
		txtPwd.setBounds(287, 174, 182, 26);
		panelGRXX.add(txtPwd);
		
		JLabel label_4 = new JLabel("\u90E8\u95E8\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_4.setBounds(203, 210, 82, 28);
		panelGRXX.add(label_4);
		
		txtPower = new JTextField();
		txtPower.setColumns(10);
		txtPower.setBounds(287, 217, 182, 26);
		panelGRXX.add(txtPower);
		
		JLabel label_5 = new JLabel("\u6743\u9650\uFF1A");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		label_5.setBounds(203, 251, 82, 28);
		panelGRXX.add(label_5);
		
		txtDepid = new JTextField();
		txtDepid.setColumns(10);
		txtDepid.setBounds(287, 258, 182, 26);
		panelGRXX.add(txtDepid);


		
		JButton button = new JButton("\u786E\u8BA4\u4FEE\u6539");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// ������Ϣ�޸�
				
			}
		});
		button.setForeground(Color.BLACK);
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(203, 319, 113, 36);
		panelGRXX.add(button);
		
		JButton button_6 = new JButton("\u53D6\u6D88");
		button_6.setForeground(Color.BLACK);
		button_6.setBackground(Color.LIGHT_GRAY);
		button_6.setBounds(356, 319, 113, 36);
		panelGRXX.add(button_6);
		
		JLabel lblNewLabel = new JLabel("\u4E2A\u4EBA\u4FE1\u606F\u7BA1\u7406");
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 20));
		lblNewLabel.setBounds(276, 28, 127, 28);
		panelGRXX.add(lblNewLabel);
		panelHTGL.setBounds(167, 88, 679, 381);
		contentPane.add(panelHTGL);
		panelHTGL.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(0, 127, 594, 241);
		panelHTGL.add(scrollPane_2);
		
		tableHTGL = new JTable();
		
		scrollPane_2.setViewportView(tableHTGL);
		
		JLabel label_7 = new JLabel("\u8BF7\u8F93\u5165\u67E5\u8BE2\u5185\u5BB9\uFF1A");
		label_7.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_7.setBounds(39, 64, 157, 29);
		panelHTGL.add(label_7);
		
		textHTGL = new JTextField();
		textHTGL.setColumns(10);
		textHTGL.setBounds(186, 64, 252, 29);
		panelHTGL.add(textHTGL);
		
		JButton button_12 = new JButton("\u67E5\u8BE2");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String aname = textHTGL.getText();
				HTGLdataBind(aname);
			}
		});
		button_12.setForeground(Color.BLACK);
		button_12.setBackground(Color.CYAN);
		button_12.setBounds(468, 60, 74, 36);
		panelHTGL.add(button_12);
		
		JButton button_17 = new JButton("\u65B0\u589E");
		button_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//����
				HAdd hAdd = new HAdd();
				hAdd.setVisible(true);
			}
		});
		button_17.setForeground(Color.BLACK);
		button_17.setBackground(Color.CYAN);
		button_17.setBounds(605, 159, 74, 36);
		panelHTGL.add(button_17);
		
		JButton button_18 = new JButton("\u5220\u9664");
		button_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ɾ��
				// �ж��Ƿ��б�ѡ�е���
				if (tableHTGL.getSelectedRowCount()>0) {
					// �õ�������ʾ���ݵ��±�
					int index = tableHTGL.getSelectedRow();
					// �õ���Ӧ���ݵ�Id�ֶ�
					int aid = agreements.get(index).getAid();
					// ����sql���
					String sql = "delete from agreement where aid =?";
					//ִ��
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, aid)) {
						HTGLdataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}
			
			
			
			}
		});
		button_18.setForeground(Color.BLACK);
		button_18.setBackground(Color.CYAN);
		button_18.setBounds(605, 218, 74, 36);
		panelHTGL.add(button_18);
		
		JButton button_19 = new JButton("\u4FEE\u6539");
		button_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// �޸�
				if (tableHTGL.getSelectedRowCount()>0) {
					int index = tableHTGL.getSelectedRow();
					agreement = agreements.get(index);
					Hupdate hupdate = new Hupdate() ;
					hupdate.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");

				}
			
			}
		});
		button_19.setForeground(Color.BLACK);
		button_19.setBackground(Color.CYAN);
		button_19.setBounds(605, 267, 74, 36);
		panelHTGL.add(button_19);
		
		JButton button_20 = new JButton("\u5BFC\u51FA");
		button_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//��ͬ��������
				String path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
				path.replaceAll("\\\\", "/");
				// System.out.println(path);
				JOptionPane.showMessageDialog(null, "�����ɹ���������agreement.xls�ļ���", "����", JOptionPane.INFORMATION_MESSAGE);
				ExcelExporter exportExcel1 = new ExcelExporter(tableHTGL,path+"/agrrrment.xls");
				exportExcel1.export();
			}
		});
		button_20.setForeground(Color.BLACK);
		button_20.setBackground(Color.CYAN);
		button_20.setBounds(605, 317, 74, 36);
		panelHTGL.add(button_20);
		
		panelBMGL.setBounds(167, 88, 679, 381);
		contentPane.add(panelBMGL);
		panelBMGL.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(14, 110, 545, 258);
		panelBMGL.add(scrollPane_1);
		
		tableBMGL = new JTable();
		
		scrollPane_1.setViewportView(tableBMGL);
		
		JLabel label_6 = new JLabel("\u8BF7\u8F93\u5165\u67E5\u8BE2\u5185\u5BB9\uFF1A");
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		label_6.setBounds(30, 54, 166, 29);
		panelBMGL.add(label_6);
		
		textBMGL = new JTextField();
		textBMGL.setColumns(10);
		textBMGL.setBounds(184, 54, 238, 30);
		panelBMGL.add(textBMGL);
		
		JButton butBMGL = new JButton("\u67E5\u8BE2");
		butBMGL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String depname = textBMGL.getText();
				BMGLdataBind(depname);
			}
		});
		butBMGL.setForeground(Color.BLACK);
		butBMGL.setBackground(Color.CYAN);
		butBMGL.setBounds(432, 50, 74, 36);
		panelBMGL.add(butBMGL);
		
		JButton button_13 = new JButton("\u65B0\u589E");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BAdd bAdd = new BAdd();
				bAdd.setVisible(true);
			}
		});
		button_13.setForeground(Color.BLACK);
		button_13.setBackground(Color.CYAN);
		button_13.setBounds(584, 132, 74, 36);
		panelBMGL.add(button_13);
		
		JButton button_14 = new JButton("\u5220\u9664");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				// ɾ��
				// �ж��Ƿ��б�ѡ�е���
				if (tableBMGL.getSelectedRowCount()>0) {
					// �õ�������ʾ���ݵ��±�
					int index = tableBMGL.getSelectedRow();
					// �õ���Ӧ���ݵ�Id�ֶ�
					int depid = depts.get(index).getDepid();
					// ����sql���
					String sql = "delete from dept where depid =?";
					//ִ��
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, depid)) {
						BMGLdataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}
			
			
			
			}
		});
		button_14.setForeground(Color.BLACK);
		button_14.setBackground(Color.CYAN);
		button_14.setBounds(584, 191, 74, 36);
		panelBMGL.add(button_14);
		
		JButton button_15 = new JButton("\u4FEE\u6539");
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {


				// �޸�
				
				
				if (tableBMGL.getSelectedRowCount()>0) {
					int index = tableBMGL.getSelectedRow();
				dept = depts.get(index);
					Bupdate bupdate= new Bupdate();
					bupdate.setVisible(true);
					

				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");
				}
			
			
			}
		});
		button_15.setForeground(Color.BLACK);
		button_15.setBackground(Color.CYAN);
		button_15.setBounds(584, 240, 74, 36);
		panelBMGL.add(button_15);
		
		JButton button_16 = new JButton("\u5BFC\u51FA");
		button_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//���Ź�������
				String path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
				path.replaceAll("\\\\", "/");
				// System.out.println(path);
				JOptionPane.showMessageDialog(null, "�����ɹ���������dept.xls�ļ���", "����", JOptionPane.INFORMATION_MESSAGE);
				ExcelExporter exportExcel1 = new ExcelExporter(tableBMGL,path+"/dept.xls");
				exportExcel1.export();

			
			}
		});
		button_16.setForeground(Color.BLACK);
		button_16.setBackground(Color.CYAN);
		button_16.setBounds(584, 290, 74, 36);
		panelBMGL.add(button_16);
		panelYHGL.setBounds(167, 88, 679, 381);
		contentPane.add(panelYHGL);
		panelYHGL.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u67E5\u8BE2\u5185\u5BB9\uFF1A");
		label.setBounds(14, 81, 163, 29);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		panelYHGL.add(label);
		
		textYHGL = new JTextField();
		textYHGL.setBounds(158, 84, 240, 29);
		textYHGL.setColumns(10);
		panelYHGL.add(textYHGL);
		
		JButton button_7 = new JButton("\u67E5\u8BE2");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = textYHGL.getText();
				YHGLdataBind(username);
			}
		});
		button_7.setBounds(437, 77, 74, 36);
		button_7.setForeground(Color.BLACK);
		button_7.setBackground(Color.CYAN);
		panelYHGL.add(button_7);
		
		JButton button_8 = new JButton("\u65B0\u589E");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				YAdd yAdd = new YAdd();
				yAdd.setVisible(true);
			}
		});
		button_8.setBounds(595, 133, 74, 36);
		button_8.setForeground(Color.BLACK);
		button_8.setBackground(Color.CYAN);
		panelYHGL.add(button_8);
		
		JButton button_9 = new JButton("\u5220\u9664");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				

				
				// ɾ��
				// �ж��Ƿ��б�ѡ�е���
				if (tableYHGL.getSelectedRowCount()>0) {
					// �õ�������ʾ���ݵ��±�
					int index = tableYHGL.getSelectedRow();
					// �õ���Ӧ���ݵ�Id�ֶ�
					int uid = userss.get(index).getUid();
					// ����sql���
					String sql = "delete from users where uid =?";
					//ִ��
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, uid)) {
						YHGLdataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}
			
			
			}
		});
		button_9.setBounds(595, 192, 74, 36);
		button_9.setForeground(Color.BLACK);
		button_9.setBackground(Color.CYAN);
		panelYHGL.add(button_9);
		
		JButton button_10 = new JButton("\u4FEE\u6539");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �޸�
				if (tableYHGL.getSelectedRowCount()>0){
					int index = tableYHGL.getSelectedRow();
					users = userss.get(index);
					Yupdate yupdate = new Yupdate();
					yupdate.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");

				}
			}
		});
		button_10.setBounds(595, 241, 74, 36);
		button_10.setForeground(Color.BLACK);
		button_10.setBackground(Color.CYAN);
		panelYHGL.add(button_10);
		
		JButton button_11 = new JButton("\u5BFC\u51FA");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//�û���������
				String path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
				path.replaceAll("\\\\", "/");
				// System.out.println(path);
				JOptionPane.showMessageDialog(null, "�����ɹ���������users.xls�ļ���", "����", JOptionPane.INFORMATION_MESSAGE);
				ExcelExporter exportExcel1 = new ExcelExporter(tableYHGL,path+"/users.xls");
				exportExcel1.export();

			}
		});
		button_11.setBounds(595, 291, 74, 36);
		button_11.setForeground(Color.BLACK);
		button_11.setBackground(Color.CYAN);
		panelYHGL.add(button_11);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 139, 545, 188);
		panelYHGL.add(scrollPane);
		
		tableYHGL = new JTable();
		
		scrollPane.setViewportView(tableYHGL);
		HTGLdataBind("");
		BMGLdataBind("");
		YHGLdataBind("");
		
		JLabel lblNewLabel_1 = new JLabel("CRM\u7BA1\u7406\u5458\u540E\u53F0\u754C\u9762");
		lblNewLabel_1.setBounds(294, 37, 260, 37);
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.BOLD, 25));
		contentPane.add(lblNewLabel_1);
		
		
		JLabel lblNewLabel_2 = new JLabel("��ӭ��"+Login.name+"����Ա��");
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.BOLD, 15));
		lblNewLabel_2.setBounds(624, 21, 175, 24);
		contentPane.add(lblNewLabel_2);
		
		lblTimer = new JLabel("");
		timer = new Timer(1000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateTimer();
			}
		});
		timer.start();
		lblTimer.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblTimer.setBounds(624, 54, 214, 24);
		
		contentPane.add(lblTimer);
		setLocationRelativeTo(null);
	}
}
