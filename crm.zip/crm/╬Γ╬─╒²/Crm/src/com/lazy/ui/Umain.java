package com.lazy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.Timer;


import com.lazy.dao.BaseDao;
import com.lazy.dao.ExcelExporter;
import com.lazy.pojo.Business;
import com.lazy.pojo.Contact;
import com.lazy.pojo.Customer;
import com.lazy.pojo.Feedback;
import com.lazy.pojo.Product;
import com.lazy.pojo.Project;
import com.lazy.pojo.Schedule;
import com.lazy.pojo.Schedule;
import com.lazy.pojo.Users;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Panel;

import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;

public class Umain extends JFrame {

	private JPanel contentPane;
	private JButton btnNewButton;
	private JButton button;
	private JButton button_1;
	private JLabel lblNewLabel;
	private static ArrayList<Schedule> schedules;
	public static Schedule schedule;
	private JMenuBar menuBar;
	private JMenu mnSY;
	private JMenu mnQZKH;
	private JMenu mnKH;
	private JMenu mnLXR;
	private JMenu mnSYHD;
	private JMenu mnKHFK;
	private JMenu mnWDCP;
	private JPanel panelWDRC;
	private JPanel panelWDXM;
	private JLabel lblNewLabel_1;
	private JTextField textWDRC;
	private JScrollPane scrollPane;
	private JTable table;
	private JTextField textWDXM;
	private static ArrayList<Project> projects;
	public static Project project;
	private JTable table_1;
	private JTextField textSY;
	private JTable table_2;
	private static ArrayList<Customer> customers;
	public static Customer customer;
	private JTextField textQZKH;
	private JTable table_3;
	private JTextField textKH;
	private JTable table_4;
	private JTextField textLXR;
	private JTable table_5;
	private JTextField textSYHD;
	private JTable table_6;
	private static ArrayList<Business> businesses;
	public static Business business;
	private JTextField textKHFK;
	private JTable table_7;
	private static ArrayList<Feedback> feedbacks ;
	public static Feedback feedback ;
	private JTextField textWDCP;
	private JTable table_8;
	private static ArrayList<Product> products ;
	public static Product product ;
	
	private Timer timer;
	private JLabel lblTimer;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			JFrame.setDefaultLookAndFeelDecorated(true);
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Umain frame = new Umain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void updateTimer(){
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
		lblTimer.setText(sdf.format(date));
	}
	public  void WDRCdataBind(String taskphone) {
		BaseDao baseDao = new BaseDao();
		String sql = "select*from schedule where taskphone like?";
		ResultSet rs = baseDao.query(sql,"%"+ taskphone + "%");
		
		schedules = new ArrayList<>();
		Schedule schedule = null;
		try {
			while (rs.next()) {
			schedule = new Schedule(); 
			schedule.setSid(rs.getInt("sid"));
			schedule.setSdate(rs.getString("sdate"));
			schedule.setTask(rs.getString("task"));
			schedule.setTaskphone(rs.getString("taskphone"));
			schedule.setMeeting(rs.getString("meeting"));
			schedule.setUid(rs.getString("uid"));
			schedules.add(schedule);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[] [] data = new Object[schedules.size()][];
		for (int i = 0; i < schedules.size(); i++) {
			data[i] = new Object[] {
					schedules.get(i).getSid(),
					schedules.get(i).getSdate(),
					schedules.get(i).getTask(),
					schedules.get(i).getTaskphone(),
					schedules.get(i).getMeeting(),
					schedules.get(i).getUid()
					};
		}
		table.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u65E5\u7A0B\u5E8F\u53F7", "\u65E5\u671F", "\u4EFB\u52A1", "\u7535\u8BDD", "\u4F1A\u8BAE", "\u7ECF\u529E\u4EBA"
				}
			));
	}
	public void WDXMdataBind(String proname) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from project where proname like?";
		ResultSet rs = baseDao.query(sql, "%" + proname + "%");
		projects = new ArrayList<>();
		Project project = null;

		try {
			while (rs.next()) {
				project = new Project();
				project.setPid(rs.getInt("pid"));
				project.setProname(rs.getString("proname"));
				project.setDescribes(rs.getString("describes"));
				project.setStarttime(rs.getString("starttime"));
				project.setEndtime(rs.getString("endtime"));
				project.setUid(rs.getString("uid"));
				projects.add(project);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[projects.size()][];
		for (int i = 0; i < projects.size(); i++) {
			data[i] = new Object[] { projects.get(i).getPid(), projects.get(i).getProname(),
					projects.get(i).getDescribes(), projects.get(i).getStarttime(), projects.get(i).getEndtime(),
					projects.get(i).getUid()

			};
		}
		table_1.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u9879\u76EE\u7F16\u53F7", "\u9879\u76EE\u540D\u79F0", "\u9879\u76EE\u63CF\u8FF0", "\u5F00\u59CB\u65F6\u95F4", "\u7ED3\u675F\u65F6\u95F4", "\u7528\u6237"
				}
			));

	}
	
	public void SYdataBind(String contactt) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from customer join contact on customer.contactid = contact.contactid where contact like? ";
		ResultSet rs = baseDao.query(sql,"%"+contactt+"%");
		customers = new ArrayList<>();
		Customer customer = null;
		
		try {
			while(rs.next()) {
				customer = new Customer();
				customer.setCid(rs.getInt("cid"));
				customer.setCname(rs.getString("cname"));
				customer.setAddress(rs.getString("address"));
				customer.setContact(rs.getString("contact"));
				customer.setMobile(rs.getString("mobile"));
				customer.setMail(rs.getString("mail"));
				customer.setLatent(rs.getString("latent"));
				customer.setSource(rs.getString("source"));
				customer.setEnglishname(rs.getString("englishname"));
				customer.setJob(rs.getString("job"));
				customer.setDept(rs.getString("dept"));
				customer.setDeptmanager(rs.getString("deptmanager"));
				customer.setFax(rs.getString("fax"));
				customer.setWebsite(rs.getString("website"));
				customer.setTelephone(rs.getString("telephone"));
				customer.setStatue(rs.getString("statue"));
				customer.setStatuedesc(rs.getString("statuedesc"));
				
				//���
				
				Contact contact = new Contact();
				contact.setContactid(rs.getInt("contactid"));
				contact.setConname(rs.getString("conname"));
				contact.setCondate(rs.getString("condate"));
				contact.setNick(rs.getString("nick"));
				contact.setBoss(rs.getString("boss"));
				contact.setWife(rs.getString("wife"));
				customer.setWj(contact);
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[customers.size()][];
		for (int i = 0; i < customers.size(); i++) {
			data[i] = new Object[] {
					customers.get(i).getCid(),
					customers.get(i).getCname(),
					customers.get(i).getAddress(),
					customers.get(i).getContact(),
					customers.get(i).getMobile(),
					customers.get(i).getMail(),
					customers.get(i).getLatent(),
					customers.get(i).getSource(),
					customers.get(i).getEnglishname(),
					customers.get(i).getJob(),
					customers.get(i).getDept(),
					customers.get(i).getDeptmanager(),
					customers.get(i).getFax(),
					customers.get(i).getWebsite(),
					customers.get(i).getTelephone(),
					customers.get(i).getStatue(),
					customers.get(i).getStatuedesc(),
					customers.get(i).getWj().getConname()
			};
		}
		table_2.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u5BA2\u6237\u7F16\u53F7", "\u5BA2\u6237\u540D", "\u5BA2\u6237\u5730\u5740", "\u8054\u7CFB\u4EBA", "\u624B\u673A\u53F7", "\u7535\u5B50\u90AE\u4EF6", "\u6F5C\u5728\u5BA2\u6237", "\u6E20\u9053\u6765\u6E90", "\u82F1\u6587\u540D", "\u804C\u52A1", "\u90E8\u95E8", "\u7ECF\u7406", "\u4F20\u771F", "\u7F51\u7AD9", "\u5EA7\u673A", "\u66F4\u8FDB\u72B6\u6001", "\u72B6\u6001\u8BF4\u660E", "\u8054\u7CFB\u4EBA"
				}
			));
	}
	
	public void QZKHdataBind(String contactt) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from customer join contact on customer.contactid = contact.contactid where contact like? and latent=2";
		ResultSet rs = baseDao.query(sql,"%"+contactt+"%");
		customers = new ArrayList<>();
		Customer customer = null;
		
		try {
			while(rs.next()) {
				customer = new Customer();
				customer.setCid(rs.getInt("cid"));
				customer.setCname(rs.getString("cname"));
				customer.setAddress(rs.getString("address"));
				customer.setContact(rs.getString("contact"));
				customer.setMobile(rs.getString("mobile"));
				customer.setMail(rs.getString("mail"));
				customer.setLatent(rs.getString("latent"));
				customer.setSource(rs.getString("source"));
				customer.setEnglishname(rs.getString("englishname"));
				customer.setJob(rs.getString("job"));
				customer.setDept(rs.getString("dept"));
				customer.setDeptmanager(rs.getString("deptmanager"));
				customer.setFax(rs.getString("fax"));
				customer.setWebsite(rs.getString("website"));
				customer.setTelephone(rs.getString("telephone"));
				customer.setStatue(rs.getString("statue"));
				customer.setStatuedesc(rs.getString("statuedesc"));
				
				//���
				
				Contact contact = new Contact();
				contact.setContactid(rs.getInt("contactid"));
				contact.setConname(rs.getString("conname"));
				contact.setCondate(rs.getString("condate"));
				contact.setNick(rs.getString("nick"));
				contact.setBoss(rs.getString("boss"));
				contact.setWife(rs.getString("wife"));
				customer.setWj(contact);
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[customers.size()][];
		for (int i = 0; i < customers.size(); i++) {
			data[i] = new Object[] {
					customers.get(i).getCid(),
					customers.get(i).getCname(),
					customers.get(i).getAddress(),
					customers.get(i).getContact(),
					customers.get(i).getMobile(),
					customers.get(i).getMail(),
					customers.get(i).getLatent(),
					customers.get(i).getSource(),
					customers.get(i).getEnglishname(),
					customers.get(i).getJob(),
					customers.get(i).getDept(),
					customers.get(i).getDeptmanager(),
					customers.get(i).getFax(),
					customers.get(i).getWebsite(),
					customers.get(i).getTelephone(),
					customers.get(i).getStatue(),
					customers.get(i).getStatuedesc(),
					customers.get(i).getWj().getConname()
			};
		}
		table_3.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u5BA2\u6237\u7F16\u53F7", "\u5BA2\u6237\u540D", "\u5BA2\u6237\u5730\u5740", "\u8054\u7CFB\u4EBA", "\u624B\u673A\u53F7", "\u7535\u5B50\u90AE\u7BB1", "\u6F5C\u5728\u5BA2\u6237", "\u6E20\u9053", "\u82F1\u6587\u540D", "\u804C\u52A1", "\u90E8\u95E8", "\u7ECF\u7406", "\u4F20\u771F", "\u7F51\u7EDC", "\u5EA7\u673A", "\u8DDF\u8FDB\u60C5\u51B5", "\u72B6\u6001", "\u8054\u7CFB\u4EBA"
				}
			));
	}
	public void KHdataBind(String contactt) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from customer join contact on customer.contactid = contact.contactid where contact like? and latent=1";
		ResultSet rs = baseDao.query(sql,"%"+contactt+"%");
		customers = new ArrayList<>();
		Customer customer = null;
		
		try {
			while(rs.next()) {
				customer = new Customer();
				customer.setCid(rs.getInt("cid"));
				customer.setCname(rs.getString("cname"));
				customer.setAddress(rs.getString("address"));
				customer.setContact(rs.getString("contact"));
				customer.setMobile(rs.getString("mobile"));
				customer.setMail(rs.getString("mail"));
				customer.setLatent(rs.getString("latent"));
				customer.setSource(rs.getString("source"));
				customer.setEnglishname(rs.getString("englishname"));
				customer.setJob(rs.getString("job"));
				customer.setDept(rs.getString("dept"));
				customer.setDeptmanager(rs.getString("deptmanager"));
				customer.setFax(rs.getString("fax"));
				customer.setWebsite(rs.getString("website"));
				customer.setTelephone(rs.getString("telephone"));
				customer.setStatue(rs.getString("statue"));
				customer.setStatuedesc(rs.getString("statuedesc"));
				
				//���
				
				Contact contact = new Contact();
				contact.setContactid(rs.getInt("contactid"));
				contact.setConname(rs.getString("conname"));
				contact.setCondate(rs.getString("condate"));
				contact.setNick(rs.getString("nick"));
				contact.setBoss(rs.getString("boss"));
				contact.setWife(rs.getString("wife"));
				customer.setWj(contact);
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[customers.size()][];
		for (int i = 0; i < customers.size(); i++) {
			data[i] = new Object[] {
					customers.get(i).getCid(),
					customers.get(i).getCname(),
					customers.get(i).getAddress(),
					customers.get(i).getContact(),
					customers.get(i).getMobile(),
					customers.get(i).getMail(),
					customers.get(i).getLatent(),
					customers.get(i).getSource(),
					customers.get(i).getEnglishname(),
					customers.get(i).getJob(),
					customers.get(i).getDept(),
					customers.get(i).getDeptmanager(),
					customers.get(i).getFax(),
					customers.get(i).getWebsite(),
					customers.get(i).getTelephone(),
					customers.get(i).getStatue(),
					customers.get(i).getStatuedesc(),
					customers.get(i).getWj().getConname()
			};
		}
		table_4.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u5BA2\u6237\u7F16\u53F7", "\u5BA2\u6237\u540D", "\u5730\u5740", "\u8054\u7CFB\u4EBA", "\u624B\u673A\u53F7", "\u90AE\u4EF6", "\u5BA2\u6237", "\u6E20\u9053", "\u82F1\u6587\u540D", "\u804C\u52A1", "\u90E8\u95E8", "\u7ECF\u7406", "\u4F20\u771F", "\u7F51\u7AD9", "\u5EA7\u673A", "\u8DDF\u8FDB\u72B6\u6001", "\u72B6\u6001", "\u8054\u7CFB\u4EBA"
				}
			));
	}
	public void LXRdataBind( String cname) {
		BaseDao baseDao = new BaseDao();
		String sql = "select * from customer join contact on customer.contactid = contact.contactid where cname like?";
		ResultSet rs = baseDao.query(sql,"%"+cname+"%");
		customers = new ArrayList<>();
		Customer customer = null;
		
		try {
			while(rs.next()) {
				customer = new Customer();
				customer.setCid(rs.getInt("cid"));
				customer.setCname(rs.getString("cname"));
				customer.setAddress(rs.getString("address"));
				customer.setContact(rs.getString("contact"));
				customer.setMobile(rs.getString("mobile"));
				customer.setMail(rs.getString("mail"));
				customer.setLatent(rs.getString("latent"));
				customer.setSource(rs.getString("source"));
				customer.setEnglishname(rs.getString("englishname"));
				customer.setJob(rs.getString("job"));
				customer.setDept(rs.getString("dept"));
				customer.setDeptmanager(rs.getString("deptmanager"));
				customer.setFax(rs.getString("fax"));
				customer.setWebsite(rs.getString("website"));
				customer.setTelephone(rs.getString("telephone"));
				customer.setStatue(rs.getString("statue"));
				customer.setStatuedesc(rs.getString("statuedesc"));
				
				//���
				
				Contact contact = new Contact();
				contact.setContactid(rs.getInt("contactid"));
				contact.setConname(rs.getString("conname"));
				contact.setCondate(rs.getString("condate"));
				contact.setNick(rs.getString("nick"));
				contact.setBoss(rs.getString("boss"));
				contact.setWife(rs.getString("wife"));
				customer.setWj(contact);
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[customers.size()][];
		for (int i = 0; i < customers.size(); i++) {
			data[i] = new Object[] {
					customers.get(i).getWj().getContactid(),
					customers.get(i).getWj().getConname(),
					customers.get(i).getEnglishname(),
					customers.get(i).getCname(),
					customers.get(i).getSource(),
					customers.get(i).getJob(),
					customers.get(i).getDept(),
					customers.get(i).getWj().getCondate(),
					customers.get(i).getDeptmanager(),
					customers.get(i).getWj().getNick(),
					customers.get(i).getWj().getBoss(),
					customers.get(i).getTelephone(),
					customers.get(i).getFax(),
					customers.get(i).getMail(),
					customers.get(i).getWj().getWife()
					
			};
		}
		table_5.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u8054\u7CFB\u4EBA\u7F16\u53F7", "\u59D3\u540D", "\u82F1\u6587\u540D", "\u5BA2\u6237\u540D", "\u6E20\u9053\u6765\u6E90", "\u804C\u52A1", "\u90E8\u95E8", "\u51FA\u751F\u65E5\u671F", "\u7ECF\u7406", "\u6635\u79F0", "\u8001\u677F", "\u5EA7\u673A", "\u4F20\u771F", "\u7535\u5B50\u90AE\u4EF6", "\u7231\u4EBA\u59D3\u540D"
				}
			));
	}
	
	public void SYHDdataBind( String username){
		BaseDao baseDao = new BaseDao();
		String sql = "select * from business join users on business.id = users.uid where username like ?";
		ResultSet rs = baseDao.query(sql,"%"+username+"%");
		businesses = new ArrayList<>();
		Business business = null;
		
		try {
			while(rs.next()){
				business = new Business();
				business.setId(rs.getInt("id"));
				business.setContent(rs.getString("content"));
				business.setPrice(rs.getString("price"));
				// ���
				Users users = new Users();
				users.setUid(rs.getInt("uid"));
				users.setUsername(rs.getString("username"));
				business.setUsers(users);
				businesses.add(business);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[businesses.size()][];
		for (int i = 0; i < businesses.size(); i++) {
			data[i] = new Object[]{
				businesses.get(i).getId(),
				businesses.get(i).getContent(),
				businesses.get(i).getPrice(),
				businesses.get(i).getUsers().getUsername()
			};
		}
		table_6.setModel(new DefaultTableModel(
			data,
				new String[] {
					"\u5546\u4E1A\u6D3B\u52A8\u7F16\u53F7", "\u6D3B\u52A8\u5185\u5BB9", "\u6D3B\u52A8\u7ECF\u8D39", "\u7ECF\u529E\u4EBA"
				}
			));
	}

	public void KHFKdataBind( String cname){
		BaseDao baseDao = new BaseDao();
		String sql = "select * from feedback where cname like?";
		ResultSet rs  = baseDao.query(sql,"%"+cname+"%");
		feedbacks = new ArrayList<>();
		Feedback feedback = null;
		
		try {
			while(rs.next()){
			
				feedback = new Feedback();
				feedback.setFid(rs.getInt("fid"));
				feedback.setCname(rs.getString("cname"));
				feedback.setCancat(rs.getString("cancat"));
				feedback.setFdate(rs.getString("fdate"));
				feedback.setMobile(rs.getString("mobile"));
				feedback.setPurpose(rs.getString("purpose"));
				feedback.setResult(rs.getString("result"));
				feedback.setState(rs.getString("state"));
				feedback.setOperator(rs.getString("operator"));
				feedbacks.add(feedback);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[feedbacks.size()][];
		for (int i = 0; i < feedbacks.size(); i++) {
			data[i] =  new Object[]{
				feedbacks.get(i).getFid(),
				feedbacks.get(i).getCname(),
				feedbacks.get(i).getCancat(),
				feedbacks.get(i).getFdate(),
				feedbacks.get(i).getMobile(),
				feedbacks.get(i).getPurpose(),
				feedbacks.get(i).getResult(),
				feedbacks.get(i).getState(),
				feedbacks.get(i).getOperator()
			};
		}
		table_7.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u53CD\u9988\u7F16\u53F7", "\u673A\u6784\u540D\u79F0", "\u8054\u7CFB\u4EBA", "\u53CD\u9988\u65F6\u95F4", "\u624B\u673A", "\u53CD\u9988\u76EE\u7684", "\u53CD\u9988\u72B6\u6001", "\u53CD\u9988\u7ED3\u679C", "\u53CD\u9988\u5904\u7406\u4EBA"
				}
			));
			
		}
		
	public void WDCPdataBind( String pname){
		BaseDao baseDao = new BaseDao();
		String sql = "select * from product where pname like?";
		ResultSet rs = baseDao.query(sql,"%"+pname+"%");
		products = new ArrayList<>();
		Product product = null;
		
		try {
			while(rs.next()){
				product = new Product();
				product.setPid(rs.getInt("pid"));
				product.setPname(rs.getString("pname"));
				product.setPtype(rs.getString("ptype"));
				product.setInfo(rs.getString("info"));
				product.setServer(rs.getString("server"));
				product.setPrice(rs.getString("price"));
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object[][] data = new Object[products.size()][];
		for (int i = 0; i < products.size(); i++) {
			data[i] = new Object[]{
					products.get(i).getPid(),
					products.get(i).getPname(),
					products.get(i).getPtype(),
					products.get(i).getInfo(),
					products.get(i).getServer(),
					products.get(i).getPrice()
					
					
			};
		}
		table_8.setModel(new DefaultTableModel(
				data,
				new String[] {
					"\u7F16\u53F7", "\u4EA7\u54C1\u540D\u79F0", "\u4EA7\u54C1\u7C7B\u522B", "\u4EA7\u54C1\u4ECB\u7ECD", "\u4EA7\u54C1\u670D\u52A1", "\u4EA7\u54C1\u62A5\u4EF7"
				}
			));
		
	}
	
	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public Umain() throws SQLException {
		JPanel panelWDCP = new JPanel();
		panelWDCP.setBounds(136, 113, 741, 309);
		JPanel panelKHFK = new JPanel();
		panelKHFK.setBounds(136, 113, 741, 309);
		JPanel panelSYHD = new JPanel();
		panelSYHD.setBounds(136, 113, 741, 309);
		JPanel panelLXR = new JPanel();
		panelLXR.setBounds(136, 113, 741, 309);
		JPanel panelKH = new JPanel();
		panelKH.setBounds(136, 116, 741, 306);
		JPanel paneQZKH = new JPanel();
		paneQZKH.setBounds(136, 116, 741, 306);
		JPanel panelSY = new JPanel();
		panelSY.setBounds(136, 116, 741, 306);
		setTitle("\u5458\u5DE5\u540E\u53F0\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 903, 498);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		btnNewButton = new JButton("\u6211\u7684\u65E5\u7A0B");
		btnNewButton.setBounds(14, 207, 93, 34);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				// �ҵ��ճ�
				panelWDRC.show();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		contentPane.setLayout(null);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		contentPane.add(btnNewButton);
		
		button = new JButton("\u6211\u7684\u9879\u76EE");
		button.setBounds(14, 293, 93, 34);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//�ҵ���Ŀ
				panelWDRC.hide();
				panelWDXM.show();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
				
			}
		});
		button.setBackground(Color.LIGHT_GRAY);
		contentPane.add(button);
		
		button_1 = new JButton("\u9000\u51FA");
		button_1.setBounds(14, 383, 93, 34);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �˳�
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		button_1.setBackground(Color.LIGHT_GRAY);
		contentPane.add(button_1);
		
		lblNewLabel = new JLabel("\u5458\u5DE5\u540E\u53F0\u7BA1\u7406\u754C\u9762");
		lblNewLabel.setBounds(334, 13, 219, 39);
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("��ӭ��"+Login.name+"Ա��!");
		lblNewLabel_2.setBounds(674, 18, 150, 34);
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.BOLD, 18));
		contentPane.add(lblNewLabel_2);
		
		menuBar = new JMenuBar();
		menuBar.setBounds(276, 62, 361, 26);
		contentPane.add(menuBar);
		
	


		
		mnSY = new JMenu("\u9996\u9875");
		mnSY.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ��ҳ
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.show();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnSY);
		
		mnQZKH = new JMenu("\u6F5C\u5728\u5BA2\u6237");
		mnQZKH.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Ǳ�ڿͻ�
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.show();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnQZKH);
		
		mnKH = new JMenu("\u5BA2\u6237");
		mnKH.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//�ͻ�
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.show();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnKH);
		
		mnLXR = new JMenu("\u8054\u7CFB\u4EBA");
		mnLXR.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//��ϵ��
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.show();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnLXR);
		
		mnSYHD = new JMenu("\u5546\u4E1A\u6D3B\u52A8");
		mnSYHD.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//��ҵ�
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.show();
				panelKHFK.hide();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnSYHD);
		
		mnKHFK = new JMenu("\u5BA2\u6237\u53CD\u9988");
		mnKHFK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//�ͻ�����
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.show();
				panelWDCP.hide();
			}
		});
		menuBar.add(mnKHFK);
		
		mnWDCP = new JMenu("\u6211\u7684\u4EA7\u54C1");
		mnWDCP.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//�ҵĲ�Ʒ
				panelWDRC.hide();
				panelWDXM.hide();
				panelSY.hide();
				paneQZKH.hide();
				panelKH.hide();
				panelLXR.hide();
				panelSYHD.hide();
				panelKHFK.hide();
				panelWDCP.show();
			}
		});
		menuBar.add(mnWDCP);
		panelWDRC = new JPanel();
		panelWDRC.setBounds(136, 116, 741, 306);
		contentPane.add(panelWDRC);
		panelWDRC.setLayout(null);
		
		lblNewLabel_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u5185\u5BB9\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.BOLD, 18));
		lblNewLabel_1.setBounds(81, 12, 188, 18);
		panelWDRC.add(lblNewLabel_1);
		
		textWDRC = new JTextField();
		textWDRC.setBounds(263, 11, 196, 24);
		panelWDRC.add(textWDRC);
		textWDRC.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String taskphone = textWDRC.getText();
				WDRCdataBind(taskphone);
			}
		});
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 18));
		btnNewButton_1.setBounds(484, 10, 113, 27);
		panelWDRC.add(btnNewButton_1);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 57, 592, 249);
		panelWDRC.add(scrollPane);
		
		table = new JTable();
		
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("\u589E\u52A0");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UAdd uAdd = new UAdd();
				uAdd.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		btnNewButton_2.setBounds(625, 74, 104, 27);
		panelWDRC.add(btnNewButton_2);
		
		JButton button_2 = new JButton("\u5220\u9664");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// ɾ��
				// �ж��Ƿ��б�ѡ�е���
				if (table.getSelectedRowCount()>0) {
					// �õ�������ʾ���ݵ��±�
					int index = table.getSelectedRow();
					// �õ���Ӧ���ݵ�Id�ֶ�
					int sid = schedules.get(index).getSid();
					// ����sql���
					String sql = "delete from schedule where sid =?";
					//ִ��
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, sid)) {
						WDRCdataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}

			}
		});
		button_2.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button_2.setBounds(625, 138, 104, 27);
		panelWDRC.add(button_2);
		
		JButton button_3 = new JButton("\u4FEE\u6539");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �޸�
				if (table.getSelectedRowCount()>0){
					int index = table.getSelectedRow();
					schedule = schedules.get(index);
					UUpdate uupdate = new UUpdate();
					uupdate.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");

				}
			}
		});
		button_3.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button_3.setBounds(625, 207, 104, 27);
		panelWDRC.add(button_3);
		
		JButton button_4 = new JButton("\u5BFC\u51FA");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//�ҵ��ճ̵���
				String path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
				path.replaceAll("\\\\", "/");
				// System.out.println(path);
				JOptionPane.showMessageDialog(null, "�����ɹ���������schedule.xls�ļ���", "����", JOptionPane.INFORMATION_MESSAGE);
				ExcelExporter exportExcel1 = new ExcelExporter(table,path+"/schedule.xls");
				exportExcel1.export();

			
				
			}
		});
		button_4.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		button_4.setBounds(625, 269, 104, 27);
		panelWDRC.add(button_4);
		panelWDXM = new JPanel();
		panelWDXM.setBounds(136, 116, 741, 306);
		contentPane.add(panelWDXM);
		panelWDXM.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u5185\u5BB9\uFF1A");
		label.setBounds(52, 14, 188, 18);
		label.setFont(new Font("΢���ź�", Font.BOLD, 18));
		panelWDXM.add(label);
		
		textWDXM = new JTextField();
		textWDXM.setBounds(234, 13, 196, 24);
		textWDXM.setColumns(10);
		panelWDXM.add(textWDXM);
		
		JButton button_5 = new JButton("\u67E5\u8BE2");
		button_5.setBounds(455, 12, 113, 27);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String  proname = textWDXM.getText();
				WDXMdataBind(proname);
			}
		});
		button_5.setFont(new Font("΢���ź�", Font.BOLD, 18));
		panelWDXM.add(button_5);
		
		JButton button_6 = new JButton("\u589E\u52A0");
		button_6.setBounds(614, 74, 104, 27);
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WAdd wAdd = new WAdd();
				wAdd.setVisible(true);
			}
		});
		button_6.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		panelWDXM.add(button_6);
		
		JButton button_7 = new JButton("\u5220\u9664");
		button_7.setBounds(614, 138, 104, 27);
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ɾ��
				if (table_1.getSelectedRowCount()>0) {
					int index = table_1.getSelectedRow();
					int pid = projects.get(index).getPid();
					String sql = "delete from project where pid =?";
				
					BaseDao baseDao = new BaseDao();
					if (baseDao.execute(sql, pid)) {
						WDXMdataBind("");
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");

					} else {
						JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�");

					}
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ�������ݣ�");
				}

			}
		});
		button_7.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		panelWDXM.add(button_7);
		
		JButton button_8 = new JButton("\u4FEE\u6539");
		button_8.setBounds(614, 207, 104, 27);
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �޸�

				if (table_1.getSelectedRowCount()>0) {
					int index = table_1.getSelectedRow();
					project = projects.get(index);
					Wupdate wupdate = new Wupdate();
					wupdate.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "����ѡ��Ҫ�޸ĵ����ݣ�");
				}
			}
		});
		button_8.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		panelWDXM.add(button_8);
		
		JButton button_9 = new JButton("\u5BFC\u51FA");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				//�ҵ���Ŀ����
				String path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
				path.replaceAll("\\\\", "/");
				// System.out.println(path);
				JOptionPane.showMessageDialog(null, "�����ɹ���������project.xls�ļ���", "����", JOptionPane.INFORMATION_MESSAGE);
				ExcelExporter exportExcel1 = new ExcelExporter(table_1,path+"/project.xls");
				exportExcel1.export();

			
				
			
			}
		});
		button_9.setBounds(614, 269, 104, 27);
		button_9.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		panelWDXM.add(button_9);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(14, 49, 590, 257);
		panelWDXM.add(scrollPane_1);
		
		table_1 = new JTable();
		
		scrollPane_1.setViewportView(table_1);
		contentPane.add(panelWDCP);
		panelWDCP.setLayout(null);
		
		JLabel label_6 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u4EA7\u54C1\u540D\u79F0\uFF1A");
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_6.setBounds(95, 10, 187, 32);
		panelWDCP.add(label_6);
		
		textWDCP = new JTextField();
		textWDCP.setColumns(10);
		textWDCP.setBounds(274, 17, 187, 21);
		panelWDCP.add(textWDCP);
		
		JButton button_15 = new JButton("\u67E5\u8BE2");
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String pname = textWDCP.getText();
				WDCPdataBind(pname);
			}
		});
		button_15.setFont(new Font("΢���ź�", Font.BOLD, 18));
		button_15.setBounds(480, 16, 93, 23);
		panelWDCP.add(button_15);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(10, 67, 731, 242);
		panelWDCP.add(scrollPane_8);
		
		table_8 = new JTable();
		WDCPdataBind("");
		
		scrollPane_8.setViewportView(table_8);
		contentPane.add(panelKHFK);
		panelKHFK.setLayout(null);
		
		JLabel label_5 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u7ECF\u529E\u4EBA\uFF1A");
		label_5.setBounds(105, 10, 170, 32);
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		panelKHFK.add(label_5);
		
		textKHFK = new JTextField();
		textKHFK.setBounds(265, 17, 187, 21);
		textKHFK.setColumns(10);
		panelKHFK.add(textKHFK);
		
		JButton button_14 = new JButton("\u67E5\u8BE2");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String cname = textKHFK.getText();
				KHFKdataBind(cname);
			}
		});
		button_14.setBounds(471, 16, 93, 23);
		button_14.setFont(new Font("΢���ź�", Font.BOLD, 18));
		panelKHFK.add(button_14);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(0, 51, 741, 258);
		panelKHFK.add(scrollPane_7);
		
		table_7 = new JTable();
		KHFKdataBind("");
		
		scrollPane_7.setViewportView(table_7);
		contentPane.add(panelSYHD);
		panelSYHD.setLayout(null);
		
		JLabel label_4 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u7ECF\u529E\u4EBA\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_4.setBounds(107, 10, 170, 32);
		panelSYHD.add(label_4);
		
		textSYHD = new JTextField();
		textSYHD.setColumns(10);
		textSYHD.setBounds(267, 17, 187, 21);
		panelSYHD.add(textSYHD);
		
		JButton button_13 = new JButton("\u67E5\u8BE2");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username =textSYHD.getText();
				SYHDdataBind(username);
				
			}
		});
		button_13.setFont(new Font("΢���ź�", Font.BOLD, 18));
		button_13.setBounds(473, 16, 93, 23);
		panelSYHD.add(button_13);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(0, 61, 741, 248);
		panelSYHD.add(scrollPane_6);
		
		table_6 = new JTable();
		SYHDdataBind("");
		
		scrollPane_6.setViewportView(table_6);
		contentPane.add(panelLXR);
		panelLXR.setLayout(null);
		
		JLabel label_3 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u8054\u7CFB\u4EBA\uFF1A");
		label_3.setBounds(110, 10, 163, 32);
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		panelLXR.add(label_3);
		
		textLXR = new JTextField();
		textLXR.setBounds(262, 17, 187, 21);
		textLXR.setColumns(10);
		panelLXR.add(textLXR);
		
		JButton button_12 = new JButton("\u67E5\u8BE2");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String cname = textLXR.getText();
				LXRdataBind(cname);
			}
		});
		button_12.setBounds(468, 16, 93, 23);
		button_12.setFont(new Font("΢���ź�", Font.BOLD, 18));
		panelLXR.add(button_12);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(0, 57, 741, 252);
		panelLXR.add(scrollPane_5);
		
		table_5 = new JTable();
		LXRdataBind("");
		
		scrollPane_5.setViewportView(table_5);
		contentPane.add(panelKH);
		panelKH.setLayout(null);
		
		JLabel label_2 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u5BA2\u6237\u540D\uFF1A");
		label_2.setBounds(95, 0, 163, 32);
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		panelKH.add(label_2);
		
		textKH = new JTextField();
		textKH.setBounds(247, 7, 187, 21);
		textKH.setColumns(10);
		panelKH.add(textKH);
		
		JButton button_11 = new JButton("\u67E5\u8BE2");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String contactt = textKH.getText();
				KHdataBind(contactt);
			}
		});
		button_11.setBounds(453, 6, 93, 23);
		button_11.setFont(new Font("΢���ź�", Font.BOLD, 18));
		panelKH.add(button_11);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(0, 38, 741, 268);
		panelKH.add(scrollPane_4);
		
		table_4 = new JTable();
		KHdataBind("");
		
		scrollPane_4.setViewportView(table_4);
		contentPane.add(paneQZKH);
		paneQZKH.setLayout(null);
		
		JLabel label_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u5BA2\u6237\u540D\uFF1A");
		label_1.setBounds(92, 13, 163, 32);
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		paneQZKH.add(label_1);
		
		textQZKH = new JTextField();
		textQZKH.setBounds(244, 20, 187, 21);
		textQZKH.setColumns(10);
		paneQZKH.add(textQZKH);
		
		JButton button_10 = new JButton("\u67E5\u8BE2");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String contactt = textQZKH.getText();
				QZKHdataBind(contactt);
			}
		});
		button_10.setBounds(450, 19, 93, 23);
		button_10.setFont(new Font("΢���ź�", Font.BOLD, 18));
		paneQZKH.add(button_10);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(0, 53, 741, 253);
		paneQZKH.add(scrollPane_3);
		
		table_3 = new JTable();
		
		scrollPane_3.setViewportView(table_3);
		QZKHdataBind("");
		contentPane.add(panelSY);
		panelSY.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u5BA2\u6237\u540D\uFF1A");
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(52, 0, 163, 32);
		panelSY.add(lblNewLabel_3);
		
		textSY = new JTextField();
		textSY.setBounds(204, 7, 187, 21);
		panelSY.add(textSY);
		textSY.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("\u67E5\u8BE2");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String contactt = textSY.getText();
				SYdataBind(contactt);
				
			}
		});
		btnNewButton_3.setFont(new Font("΢���ź�", Font.BOLD, 18));
		btnNewButton_3.setBounds(410, 6, 93, 23);
		panelSY.add(btnNewButton_3);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(0, 39, 741, 267);
		panelSY.add(scrollPane_2);
		
		table_2 = new JTable();
		SYdataBind("");
		scrollPane_2.setViewportView(table_2);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(0, 13, 135, 430);
		contentPane.add(lblNewLabel_4);
		
		lblTimer = new JLabel("");
	timer = new Timer(1000, new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			updateTimer();
		}
	});
	timer.start();
		lblTimer.setBounds(667, 62, 210, 26);
		contentPane.add(lblTimer);
		// �ҵ���Ŀ
		WDXMdataBind("");
		// �ҵ��ճ�
		WDRCdataBind("");
		setLocationRelativeTo(null);
	}
}
