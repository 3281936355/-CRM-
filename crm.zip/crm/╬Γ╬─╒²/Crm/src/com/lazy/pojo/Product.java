package com.lazy.pojo;

public class Product {
	private int pid;
	private String pname;
	private String ptype;
	private String info;
	private String server;
	private  String price;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public Product(int pid, String pname, String ptype, String info, String server, String price) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.ptype = ptype;
		this.info = info;
		this.server = server;
		this.price = price;
	}
	public Product() {
		super();
	}
}
