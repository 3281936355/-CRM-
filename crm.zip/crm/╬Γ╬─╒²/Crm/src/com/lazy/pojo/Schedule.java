package com.lazy.pojo;

public class Schedule {
	private int sid;
	private String sdate;
	private String task;
	private String taskphone ;
	private String meeting ;
	private String uid ;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSdate() {
	return sdate;
}
public void setSdate(String sdate) {
	this.sdate = sdate;
}
public String getTask() {
	return task;
}
public void setTask(String task) {
	this.task = task;
}
public String getTaskphone() {
	return taskphone;
}
public void setTaskphone(String taskphone) {
	this.taskphone = taskphone;
}
public String getMeeting() {
	return meeting;
}
public void setMeeting(String meeting) {
	this.meeting = meeting;
}
public String getUid() {
	return uid;
}
public void setUid(String uid) {
	this.uid = uid;
}
public Schedule(int sid, String sdate, String task, String taskphone, String meeting, String uid) {
	super();
	this.sid = sid;
	this.sdate = sdate;
	this.task = task;
	this.taskphone = taskphone;
	this.meeting = meeting;
	this.uid = uid;
}
public Schedule() {
	super();
}

}
