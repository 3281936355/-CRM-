package com.lazy.pojo;

public class Feedback {
	private int fid;
	private String cname;
	private 	String cancat;
	private 	String fdate;
	private 	String mobile;
	private 	String purpose;
	private  	String result;
	private 	String state;
	private 	String operator;
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCancat() {
		return cancat;
	}
	public void setCancat(String cancat) {
		this.cancat = cancat;
	}
	public String getFdate() {
		return fdate;
	}
	public void setFdate(String fdate) {
		this.fdate = fdate;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public Feedback(int fid, String cname, String cancat, String fdate, String mobile, String purpose, String result,
			String state, String operator) {
		super();
		this.fid = fid;
		this.cname = cname;
		this.cancat = cancat;
		this.fdate = fdate;
		this.mobile = mobile;
		this.purpose = purpose;
		this.result = result;
		this.state = state;
		this.operator = operator;
	}
	public Feedback() {
	}

}
