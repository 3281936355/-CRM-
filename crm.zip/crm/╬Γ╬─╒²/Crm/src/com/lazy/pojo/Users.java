package com.lazy.pojo;

public class Users {
private int uid;
private String  username ;
private String  upwd ;
private String   power;
public Dept dept;
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getUpwd() {
	return upwd;
}
public void setUpwd(String upwd) {
	this.upwd = upwd;
}
public String getPower() {
	return power;
}
public void setPower(String power) {
	this.power = power;
}
public Dept getDept() {
	return dept;
}
public void setDept(Dept dept) {
	this.dept = dept;
}
public Users(int uid, String username, String upwd, String power, Dept dept) {
	super();
	this.uid = uid;
	this.username = username;
	this.upwd = upwd;
	this.power = power;
	this.dept = dept;
}
public Users() {
	super();
}
}
