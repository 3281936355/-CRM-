package com.lazy.pojo;

public class Emp {
	private int eid;
	private 	String ename;
	private 	String eno;
	private 	String job;
	private 	String duty;
	private 	String sex;
	private String mobile;
	private String email;
	private String qq;
	private String elevel;
	private String state;
	private String isLeave;
	private String isAssign;
	private String remarks;
	private String dept;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEno() {
		return eno;
	}
	public void setEno(String eno) {
		this.eno = eno;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getDuty() {
		return duty;
	}
	public void setDuty(String duty) {
		this.duty = duty;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getElevel() {
		return elevel;
	}
	public void setElevel(String elevel) {
		this.elevel = elevel;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIsLeave() {
		return isLeave;
	}
	public void setIsLeave(String isLeave) {
		this.isLeave = isLeave;
	}
	public String getIsAssign() {
		return isAssign;
	}
	public void setIsAssign(String isAssign) {
		this.isAssign = isAssign;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Emp(int eid, String ename, String eno, String job, String duty, String sex, String mobile, String email,
			String qq, String elevel, String state, String isLeave, String isAssign, String remarks, String dept) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.eno = eno;
		this.job = job;
		this.duty = duty;
		this.sex = sex;
		this.mobile = mobile;
		this.email = email;
		this.qq = qq;
		this.elevel = elevel;
		this.state = state;
		this.isLeave = isLeave;
		this.isAssign = isAssign;
		this.remarks = remarks;
		this.dept = dept;
	}
	public Emp() {
	}

}
