package com.lazy.pojo;

public class Agreement {
private int aid;
private String aname;
private String canme;
private String ctype;
private String quality;
private String operator;
private String total;
private String payType;
private String payDate;
private String startDate;
private String endDate;
private String signer;
private String state;
public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getAname() {
	return aname;
}
public void setAname(String aname) {
	this.aname = aname;
}
public String getCanme() {
	return canme;
}
public void setCanme(String canme) {
	this.canme = canme;
}
public String getCtype() {
	return ctype;
}
public void setCtype(String ctype) {
	this.ctype = ctype;
}
public String getQuality() {
	return quality;
}
public void setQuality(String quality) {
	this.quality = quality;
}
public String getOperator() {
	return operator;
}
public void setOperator(String operator) {
	this.operator = operator;
}
public String getTotal() {
	return total;
}
public void setTotal(String total) {
	this.total = total;
}
public String getPayType() {
	return payType;
}
public void setPayType(String payType) {
	this.payType = payType;
}
public String getPayDate() {
	return payDate;
}
public void setPayDate(String payDate) {
	this.payDate = payDate;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public String getSigner() {
	return signer;
}
public void setSigner(String signer) {
	this.signer = signer;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public Agreement(int aid, String aname, String canme, String ctype, String quality, String operator, String total,
		String payType, String payDate, String startDate, String endDate, String signer, String state) {
	super();
	this.aid = aid;
	this.aname = aname;
	this.canme = canme;
	this.ctype = ctype;
	this.quality = quality;
	this.operator = operator;
	this.total = total;
	this.payType = payType;
	this.payDate = payDate;
	this.startDate = startDate;
	this.endDate = endDate;
	this.signer = signer;
	this.state = state;
}
public Agreement() {

}

}
