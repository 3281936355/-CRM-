package com.lazy.pojo;

public class Project {
	private int pid;
	private String proname;
	private String describes;
	private String starttime;
	private String endtime;
	private String  uid;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getProname() {
	return proname;
}
public void setProname(String proname) {
	this.proname = proname;
}
public String getDescribes() {
	return describes;
}
public void setDescribes(String describes) {
	this.describes = describes;
}
public String getStarttime() {
	return starttime;
}
public void setStarttime(String starttime) {
	this.starttime = starttime;
}
public String getEndtime() {
	return endtime;
}
public void setEndtime(String endtime) {
	this.endtime = endtime;
}
public String getUid() {
	return uid;
}
public void setUid(String uid) {
	this.uid = uid;
}
public Project(int pid, String proname, String describes, String starttime, String endtime, String uid) {
	super();
	this.pid = pid;
	this.proname = proname;
	this.describes = describes;
	this.starttime = starttime;
	this.endtime = endtime;
	this.uid = uid;
}
public Project() {
	super();
}

}
