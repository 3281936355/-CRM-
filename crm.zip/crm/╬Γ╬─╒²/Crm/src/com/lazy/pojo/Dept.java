package com.lazy.pojo;

public class Dept {
	private int depid;
	private String depname;
	private String depdesc;
	public int getDepid() {
		return depid;
	}
	public void setDepid(int depid) {
		this.depid = depid;
	}
	public String getDepname() {
		return depname;
	}
	public void setDepname(String depname) {
		this.depname = depname;
	}
	public String getDepdesc() {
		return depdesc;
	}
	public void setDepdesc(String depdesc) {
		this.depdesc = depdesc;
	}
	public Dept(int depid, String depname, String depdesc) {
		super();
		this.depid = depid;
		this.depname = depname;
		this.depdesc = depdesc;
	}
	public Dept() {
	}
}
