package com.lazy.pojo;

public class Customer {
	private int cid;
	private String cname;
	private String address;
	private String contact;
	private String mobile;
	private String mail;
	private String latent;
	private String source;
	private String englishname;
	private String job;
	private String dept;
	private String deptmanager;
	private String fax;
	private String website;
	private String telephone;
	private String statue;
	private String statuedesc;
	public Contact wj;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getLatent() {
		return latent;
	}
	public void setLatent(String latent) {
		this.latent = latent;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getEnglishname() {
		return englishname;
	}
	public void setEnglishname(String englishname) {
		this.englishname = englishname;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDeptmanager() {
		return deptmanager;
	}
	public void setDeptmanager(String deptmanager) {
		this.deptmanager = deptmanager;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getStatue() {
		return statue;
	}
	public void setStatue(String statue) {
		this.statue = statue;
	}
	public String getStatuedesc() {
		return statuedesc;
	}
	public void setStatuedesc(String statuedesc) {
		this.statuedesc = statuedesc;
	}
	public Contact getWj() {
		return wj;
	}
	public void setWj(Contact wj) {
		this.wj = wj;
	}
	

	
}
