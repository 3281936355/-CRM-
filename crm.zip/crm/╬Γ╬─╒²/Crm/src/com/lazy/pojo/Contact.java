package com.lazy.pojo;

public class Contact {
	private int contactid;
	private String conname;
	private String condate;
	private String nick;
	private String boss;
	private String wife;

	public int getContactid() {
		return contactid;
	}

	public void setContactid(int contactid) {
		this.contactid = contactid;
	}

	public String getConname() {
		return conname;
	}

	public void setConname(String conname) {
		this.conname = conname;
	}

	public String getCondate() {
		return condate;
	}

	public void setCondate(String condate) {
		this.condate = condate;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getBoss() {
		return boss;
	}

	public void setBoss(String boss) {
		this.boss = boss;
	}

	public String getWife() {
		return wife;
	}

	public void setWife(String wife) {
		this.wife = wife;
	}

	public Contact(int contactid, String conname, String condate, String nick, String boss, String wife) {
		super();
		this.contactid = contactid;
		this.conname = conname;
		this.condate = condate;
		this.nick = nick;
		this.boss = boss;
		this.wife = wife;
	}

	public Contact() {

	}

}
